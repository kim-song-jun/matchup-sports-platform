import { Prisma, V1GameSourceType, V1VisibilityMode } from '@prisma/client';
import { persistCanonicalGameAggregate } from '../game-source-aggregate';
import { createRosterAssertedIdentityLink } from '../games.service';

export class HistoricalFixtureNoResultImportError extends Error {
  constructor(
    readonly code: 'NO_RESULT_STATUS_UNSUPPORTED' | 'CANONICAL_MATCH_REQUIRED',
    message: string,
  ) {
    super(message);
    this.name = 'HistoricalFixtureNoResultImportError';
  }
}

export type HistoricalFixtureNoResultInput = {
  fixtureId: string;
  status: 'scheduled' | 'cancelled';
  competitionConfigVersionId: string;
  periodCount: number;
  homeTeamId: string | null;
  awayTeamId: string | null;
  homeTeamName: string;
  awayTeamName: string;
  participants: Array<{ sideKey: 'HOME' | 'AWAY'; userId?: string; displayNameSnapshot: string; jerseyNumber?: number }>;
  visibilityMode: V1VisibilityMode;
  createdAt: Date;
  updatedAt: Date;
};

export async function importHistoricalFixtureWithoutResult(tx: Prisma.TransactionClient, input: HistoricalFixtureNoResultInput) {
  if (input.status !== 'scheduled' && input.status !== 'cancelled') throw new HistoricalFixtureNoResultImportError('NO_RESULT_STATUS_UNSUPPORTED', `Fixture ${input.fixtureId} has unsupported no-result status ${input.status}.`);
  const match = await tx.v1TeamMatch.findUnique({ where: { id: input.fixtureId }, select: { id: true, tournamentId: true, competitionConfigVersionId: true, game: { select: { id: true, sourceType: true, teamMatchId: true, tournamentFixtureId: true, competitionConfigVersionId: true, state: true, currentOfficialRevisionId: true, periods: { select: { id: true } }, visibilityPolicy: { select: { mode: true } } } } } });
  const expectedState = input.status === 'cancelled' ? 'CANCELLED' : 'SCHEDULED';
  if (!match || match.competitionConfigVersionId !== input.competitionConfigVersionId || (match.game !== null && (match.game.sourceType !== V1GameSourceType.TEAM_MATCH || match.game.teamMatchId !== input.fixtureId || match.game.tournamentFixtureId !== null || match.game.competitionConfigVersionId !== input.competitionConfigVersionId || match.game.state !== expectedState || match.game.currentOfficialRevisionId !== null || match.game.periods.length !== input.periodCount || match.game.visibilityPolicy?.mode !== (input.status === 'cancelled' ? V1VisibilityMode.STATUS_ONLY : input.visibilityMode)))) throw new HistoricalFixtureNoResultImportError('CANONICAL_MATCH_REQUIRED', `Fixture ${input.fixtureId} is not a compatible canonical match.`);
  if (match.game) return match.game;
  const cancelled = input.status === 'cancelled';
  return persistCanonicalGameAggregate(tx, {
    sourceType: V1GameSourceType.TEAM_MATCH,
    sourceId: input.fixtureId,
    competitionConfigVersionId: input.competitionConfigVersionId,
    state: cancelled ? 'CANCELLED' : 'SCHEDULED',
    sides: [
      { sideKey: 'HOME', teamId: input.homeTeamId, displayNameSnapshot: input.homeTeamName },
      { sideKey: 'AWAY', teamId: input.awayTeamId, displayNameSnapshot: input.awayTeamName },
    ],
    participants: cancelled ? [] : input.participants,
    periodCount: input.periodCount,
    visibilityMode: cancelled ? V1VisibilityMode.STATUS_ONLY : input.visibilityMode,
    createdAt: input.createdAt,
    updatedAt: input.updatedAt,
  }, async (participantId, userId) => {
    await createRosterAssertedIdentityLink(tx, participantId, userId, { actorType: 'SYSTEM', systemActor: 'GAME_BACKFILL' }, 'historical_fixture_no_result_import');
  });
}
