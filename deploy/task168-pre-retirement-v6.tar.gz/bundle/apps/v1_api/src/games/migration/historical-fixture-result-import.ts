import { createHash, randomUUID } from 'node:crypto';
import { Prisma, V1GameSideKey, V1GameSourceType, V1VisibilityMode } from '@prisma/client';
import { GameResultOfficialFactsService } from '../../game-operations/game-result-official-facts.service';
import { GameResultPublicCacheService } from '../../game-operations/game-result-public-cache.service';
import { GameResultStandingsProjectionService } from '../../game-operations/game-result-standings-projection.service';
import { officialRevisionRowSelect } from '../../game-operations/official-revision-row.query';
import { normalizeOfficialRevisionRow } from '../../game-operations/official-revision-row.normalizer';
import { parseOfficialScore } from '../../game-operations/parse-official-score';
import type { OfficialRevisionRowRaw } from '../../game-operations/game-result-official-projection.types';
import { captureTournamentResultLineage } from './tournament-result-lineage';
import { createRosterAssertedIdentityLink } from '../games.service';

export class HistoricalFixtureResultImportError extends Error {
  constructor(
    readonly code:
      | 'FIXTURE_NOT_FOUND'
      | 'RESULT_NOT_FOUND'
      | 'CANONICAL_MATCH_REQUIRED'
      | 'CONFIG_REQUIRED'
      | 'GAME_ALREADY_EXISTS'
      | 'FIXTURE_NOT_COMPLETED'
      | 'REGISTRATION_INVALID'
      | 'SCORE_INVALID'
      | 'GOAL_MAPPING_INVALID',
    message: string,
  ) {
    super(message);
    this.name = 'HistoricalFixtureResultImportError';
  }
}

export interface HistoricalFixtureResultImportResult {
  created: boolean;
  fixtureId: string;
  gameId: string;
  revisionId: string;
  lineageId: string;
}

type Tx = Prisma.TransactionClient;

function visibilityMode(config: Prisma.JsonValue): V1VisibilityMode {
  if (typeof config !== 'object' || config === null || Array.isArray(config)) {
    throw new HistoricalFixtureResultImportError('CONFIG_REQUIRED', 'Pinned competition visibility config is not an object.');
  }
  const mode = (config as { mode?: unknown }).mode;
  if (mode === 'status_only') return V1VisibilityMode.STATUS_ONLY;
  if (mode === undefined || mode === 'live') return V1VisibilityMode.LIVE;
  throw new HistoricalFixtureResultImportError('CONFIG_REQUIRED', `Unsupported historical visibility mode: ${String(mode)}`);
}

function eventHash(events: unknown): string {
  return createHash('sha256').update(JSON.stringify(events), 'utf8').digest('hex');
}

export async function importHistoricalFixtureResult(
  tx: Tx,
  fixtureId: string,
): Promise<HistoricalFixtureResultImportResult> {
  const fixtureExists = await tx.v1TournamentFixture.findUnique({ where: { id: fixtureId }, select: { id: true } });
  if (!fixtureExists) throw new HistoricalFixtureResultImportError('FIXTURE_NOT_FOUND', `Fixture ${fixtureId} does not exist.`);
  // Lock canonical ownership before the legacy result graph, then let the
  // lineage helper repeat its Game -> fixture/result/goal lock order after the
  // Game exists. This makes the snapshot and duplicate-create decision atomic.
  await tx.$queryRaw`SELECT id FROM "v1_team_matches" WHERE id = ${fixtureId} FOR UPDATE`;
  await tx.$queryRaw`SELECT team_match_id FROM "v1_tournament_match_details" WHERE team_match_id = ${fixtureId} FOR UPDATE`;
  await tx.$queryRaw`SELECT id FROM "v1_games" WHERE team_match_id = ${fixtureId} OR tournament_fixture_id = ${fixtureId} ORDER BY id FOR UPDATE`;
  await tx.$queryRaw`SELECT id FROM "v1_tournament_fixtures" WHERE id = ${fixtureId} FOR UPDATE`;
  await tx.$queryRaw`SELECT id FROM "v1_tournament_fixture_results" WHERE fixture_id = ${fixtureId} FOR UPDATE`;
  await tx.$queryRaw`
    SELECT goal.id FROM "v1_tournament_fixture_goals" goal
    INNER JOIN "v1_tournament_fixture_results" result ON result.id = goal.fixture_result_id
    WHERE result.fixture_id = ${fixtureId} ORDER BY goal.id FOR UPDATE
  `;
  const fixture = await tx.v1TournamentFixture.findUnique({
    where: { id: fixtureId },
    select: {
      id: true,
      tournamentId: true,
      competitionConfigVersionId: true,
      status: true,
      createdAt: true,
      scheduledAt: true,
      result: {
        select: {
          id: true, homeScore: true, awayScore: true, hasPenalty: true,
          homePenaltyScore: true, awayPenaltyScore: true, note: true,
          recordedByAdminUserId: true, recordedAt: true, createdAt: true, updatedAt: true,
          goals: { orderBy: [{ createdAt: 'asc' }, { id: 'asc' }], select: { id: true, team: true, playerId: true, playerName: true, minute: true, createdAt: true } },
        },
      },
      homeRegistration: { select: { id: true, tournamentId: true, status: true, team: { select: { id: true, name: true } }, players: { select: { id: true, userId: true, realName: true, jerseyNumber: true, addedAt: true, removedAt: true }, orderBy: { id: 'asc' } } } },
      awayRegistration: { select: { id: true, tournamentId: true, status: true, team: { select: { id: true, name: true } }, players: { select: { id: true, userId: true, realName: true, jerseyNumber: true, addedAt: true, removedAt: true }, orderBy: { id: 'asc' } } } },
    },
  });
  if (!fixture) throw new HistoricalFixtureResultImportError('FIXTURE_NOT_FOUND', `Fixture ${fixtureId} disappeared while locked.`);
  if (!fixture.result) throw new HistoricalFixtureResultImportError('RESULT_NOT_FOUND', `Fixture ${fixtureId} has no historical result.`);
  if (fixture.status !== 'completed') throw new HistoricalFixtureResultImportError('FIXTURE_NOT_COMPLETED', `Fixture ${fixtureId} is ${fixture.status}, not completed.`);
  const homeRegistration = fixture.homeRegistration;
  const awayRegistration = fixture.awayRegistration;
  if (!homeRegistration?.team || !awayRegistration?.team) throw new HistoricalFixtureResultImportError('REGISTRATION_INVALID', `Completed fixture ${fixtureId} has no two registered teams.`);
  const recordedAt = fixture.result.recordedAt;
  const activePlayers = (registration: typeof homeRegistration) => registration.players.filter((player) => player.addedAt <= recordedAt && (player.removedAt === null || player.removedAt > recordedAt));

  const [match, details] = await Promise.all([
    tx.v1TeamMatch.findUnique({ where: { id: fixtureId }, select: { id: true, tournamentId: true, competitionConfigVersionId: true, hostTeamId: true, approvedApplicantTeamId: true, startAt: true } }),
    tx.v1TournamentMatchDetails.findUnique({ where: { teamMatchId: fixtureId }, select: { teamMatchId: true, tournamentId: true } }),
  ]);
  if (!match || match.tournamentId !== fixture.tournamentId || !details || details.tournamentId !== fixture.tournamentId || match.hostTeamId !== homeRegistration?.team?.id || match.approvedApplicantTeamId !== awayRegistration?.team?.id || homeRegistration?.tournamentId !== fixture.tournamentId || awayRegistration?.tournamentId !== fixture.tournamentId) {
    throw new HistoricalFixtureResultImportError('CANONICAL_MATCH_REQUIRED', `Fixture ${fixtureId} needs a same-UUID canonical TeamMatch and Details row before result import.`);
  }
  const fixtureScheduledAt = fixture.scheduledAt;
  if (
    (match.startAt === null) !== (fixtureScheduledAt === null) ||
    (match.startAt !== null && fixtureScheduledAt !== null && match.startAt.getTime() !== fixtureScheduledAt.getTime())
  ) {
    throw new HistoricalFixtureResultImportError(
      'CANONICAL_MATCH_REQUIRED',
      `Canonical TeamMatch ${fixtureId} startAt does not match the historical fixture scheduledAt.`,
    );
  }
  const configId = fixture.competitionConfigVersionId;
  if (!configId) throw new HistoricalFixtureResultImportError('CONFIG_REQUIRED', `Fixture ${fixtureId} has no pinned competition config.`);
  const config = await tx.v1CompetitionConfigVersion.findUnique({ where: { id: configId }, select: { id: true, visibility: true } });
  if (!config) throw new HistoricalFixtureResultImportError('CONFIG_REQUIRED', `Pinned config ${configId} does not exist.`);
  if (match.competitionConfigVersionId !== config.id) {
    throw new HistoricalFixtureResultImportError('CONFIG_REQUIRED', `Canonical TeamMatch ${fixtureId} is pinned to ${match.competitionConfigVersionId}, not the fixture config ${config.id}.`);
  }

  const [canonicalGame, legacyGame] = await Promise.all([
    tx.v1Game.findFirst({ where: { teamMatchId: fixtureId }, orderBy: { id: 'asc' }, select: { id: true, sourceType: true } }),
    tx.v1Game.findUnique({ where: { tournamentFixtureId: fixtureId }, select: { id: true, sourceType: true } }),
  ]);
  if (legacyGame) throw new HistoricalFixtureResultImportError('GAME_ALREADY_EXISTS', `Fixture ${fixtureId} already has legacy Game ${legacyGame.id}; import requires a game-less fixture.`);
  if (canonicalGame) {
    if (canonicalGame.sourceType !== V1GameSourceType.TEAM_MATCH) {
      throw new HistoricalFixtureResultImportError('GAME_ALREADY_EXISTS', `Fixture ${fixtureId} already has a non-canonical Game ${canonicalGame.id}.`);
    }
    const lineage = await tx.v1TournamentResultLineage.findUnique({ where: { originalResultId: fixture.result.id }, select: { id: true, gameId: true, officialRevisionId: true } });
    if (!lineage || lineage.gameId !== canonicalGame.id) throw new HistoricalFixtureResultImportError('GAME_ALREADY_EXISTS', `Canonical Game ${canonicalGame.id} exists without matching imported lineage for result ${fixture.result.id}.`);
    const verified = await captureTournamentResultLineage(tx, { originalFixtureId: fixtureId, teamMatchId: fixtureId, gameId: canonicalGame.id, officialRevisionId: lineage.officialRevisionId });
    return { created: false, fixtureId, gameId: canonicalGame.id, revisionId: lineage.officialRevisionId, lineageId: verified.lineageId };
  }

  const homeTeam = homeRegistration.team;
  const awayTeam = awayRegistration.team;
  const homePlayers = activePlayers(homeRegistration);
  const awayPlayers = activePlayers(awayRegistration);
  for (const goal of fixture.result.goals) {
    const players = goal.team === 'home' ? homePlayers : awayPlayers;
    if (goal.minute !== null && (!Number.isInteger(goal.minute) || goal.minute < 0)) throw new HistoricalFixtureResultImportError('GOAL_MAPPING_INVALID', `Goal ${goal.id} has invalid minute ${String(goal.minute)}.`);
    if (goal.playerId !== null && !players.some((player) => player.id === goal.playerId)) {
      throw new HistoricalFixtureResultImportError('GOAL_MAPPING_INVALID', `Goal ${goal.id} player ${goal.playerId} was not an active player of the recorded side.`);
    }
  }
  const score = {
    home: fixture.result.homeScore,
    away: fixture.result.awayScore,
    penalties: fixture.result.hasPenalty
      ? { home: fixture.result.homePenaltyScore, away: fixture.result.awayPenaltyScore }
      : null,
  };
  let parsedScore;
  try {
    parsedScore = parseOfficialScore(score);
  } catch (error) {
    throw new HistoricalFixtureResultImportError('SCORE_INVALID', error instanceof Error ? error.message : String(error));
  }
  const gameId = randomUUID();
  const revisionId = randomUUID();
  const mode = visibilityMode(config.visibility);
  await tx.v1Game.create({
    data: {
      id: gameId,
      sourceType: V1GameSourceType.TEAM_MATCH,
      teamMatchId: fixtureId,
      competitionConfigVersionId: config.id,
      state: 'ENDED',
      createdAt: fixture.createdAt,
      updatedAt: fixture.result.updatedAt,
    },
  });
  const [homeSide, awaySide] = await Promise.all([
    tx.v1GameSide.create({ data: { gameId, sideKey: V1GameSideKey.HOME, teamId: homeTeam.id, displayNameSnapshot: homeTeam.name } }),
    tx.v1GameSide.create({ data: { gameId, sideKey: V1GameSideKey.AWAY, teamId: awayTeam.id, displayNameSnapshot: awayTeam.name } }),
  ]);
  const [homeLineup, awayLineup] = await Promise.all([
    tx.v1GameLineup.create({ data: { gameId, sideId: homeSide.id, revision: 1, state: 'SUBMITTED', submittedAt: recordedAt } }),
    tx.v1GameLineup.create({ data: { gameId, sideId: awaySide.id, revision: 1, state: 'SUBMITTED', submittedAt: recordedAt } }),
  ]);
  const participantIdByTournamentPlayerId = new Map<string, string>();
  for (const [players, side, lineup] of [[homePlayers, homeSide, homeLineup], [awayPlayers, awaySide, awayLineup]] as const) {
    for (const player of players) {
      const participant = await tx.v1GameParticipant.create({ data: { gameId, sideId: side.id, lineupId: lineup.id, userId: player.userId, displayNameSnapshot: player.realName, jerseyNumber: player.jerseyNumber } , select: { id: true } });
      participantIdByTournamentPlayerId.set(player.id, participant.id);
      await createRosterAssertedIdentityLink(tx, participant.id, player.userId, { actorType: 'SYSTEM', systemActor: 'GAME_BACKFILL' }, 'historical_fixture_result_import');
    }
  }
  const goals = fixture.result.goals.map((goal) => ({
    id: goal.id,
    sideId: goal.team === 'home' ? homeSide.id : awaySide.id,
    participantId: goal.playerId === null ? null : participantIdByTournamentPlayerId.get(goal.playerId) ?? null,
    minute: goal.minute,
    period: null,
    ownGoal: false,
    playerNameSnapshot: goal.playerId === null ? goal.playerName : null,
  }));
  const eventsHash = eventHash(goals);
  const recordedBy = fixture.result.recordedByAdminUserId === null
    ? null
    : await tx.v1AdminUser.findUnique({ where: { id: fixture.result.recordedByAdminUserId }, select: { userId: true } });
  const missingScorer = fixture.result.goals.some((goal) => goal.playerId === null)
    || fixture.result.goals.filter((goal) => goal.team === 'home').length < fixture.result.homeScore
    || fixture.result.goals.filter((goal) => goal.team === 'away').length < fixture.result.awayScore;
  await tx.v1GameVisibilityPolicy.create({ data: { gameId, mode } });
  await tx.v1GameResultRevision.create({
    data: {
      id: revisionId, gameId, revision: 1, state: 'DRAFT', score: {
        ...score,
        provenance: 'HISTORICAL_FIXTURE_RESULT_IMPORT',
        originalResultId: fixture.result.id,
      },
      goalEvents: goals, eventsHash,
      createdByActorType: recordedBy ? 'USER' : 'SYSTEM',
      createdByUserId: recordedBy?.userId ?? null,
      createdBySystemActor: recordedBy ? null : 'HISTORICAL_FIXTURE_RESULT_IMPORT',
      missingScorer,
      createdAt: fixture.result.createdAt, updatedAt: fixture.result.updatedAt,
    },
  });
  const scorerIds = new Map<string, number>();
  for (const goal of fixture.result.goals) if (goal.playerId !== null) scorerIds.set(goal.playerId, (scorerIds.get(goal.playerId) ?? 0) + 1);
  await tx.v1GameResultParticipant.createMany({
    // Roster membership is participation; a missing goal must not erase an appearance.
    data: ([[homePlayers, homeSide], [awayPlayers, awaySide]] as const).flatMap(([players, side]) =>
      players.map((player) => {
        const participantId = participantIdByTournamentPlayerId.get(player.id);
        if (!participantId) throw new HistoricalFixtureResultImportError('GOAL_MAPPING_INVALID', `Roster player ${player.id} has no canonical participant.`);
        return { resultRevisionId: revisionId, participantId, sideId: side.id, started: true, minutesPlayed: null, goals: scorerIds.get(player.id) ?? 0, assists: 0, fouls: 0, cards: { yellow: 0, red: 0 }, goalkeeper: false };
      }),
    ),
  });
  await tx.v1GameResultRevision.update({
    where: { id: revisionId },
    data: { state: 'OFFICIAL', officialAt: fixture.result.recordedAt, updatedAt: fixture.result.updatedAt },
  });
  await tx.v1Game.update({ where: { id: gameId }, data: { currentOfficialRevisionId: revisionId, updatedAt: fixture.result.updatedAt } });
  const lineage = await captureTournamentResultLineage(tx, { originalFixtureId: fixtureId, teamMatchId: fixtureId, gameId, officialRevisionId: revisionId });
  const rawRows = await tx.$queryRaw<OfficialRevisionRowRaw[]>`${officialRevisionRowSelect()} WHERE revision.id = ${revisionId}`;
  if (rawRows.length !== 1) throw new HistoricalFixtureResultImportError('CANONICAL_MATCH_REQUIRED', `Imported revision ${revisionId} could not be resolved through the canonical projection source.`);
  const normalized = normalizeOfficialRevisionRow(rawRows[0]);
  const facts = new GameResultOfficialFactsService();
  const cache = new GameResultPublicCacheService();
  const standings = new GameResultStandingsProjectionService();
  const projection = cache.build(normalized, parsedScore);
  await facts.project(tx, normalized, parsedScore);
  await cache.project(tx, normalized, projection);
  await standings.project(tx, normalized);
  return { created: true, fixtureId, gameId, revisionId, lineageId: lineage.lineageId };
}
