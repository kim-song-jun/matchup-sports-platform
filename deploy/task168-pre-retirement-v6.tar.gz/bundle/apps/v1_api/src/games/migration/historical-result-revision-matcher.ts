import { Prisma } from '@prisma/client';
import { parseOfficialScore } from '../../game-operations/parse-official-score';
export type HistoricalResultGoal = {
  id: string;
  team: 'home' | 'away';
  playerId: string | null;
  playerName: string | null;
  minute: number | null;
};

export type HistoricalResultRevision = {
  id: string;
  revision: number;
  state: string;
  officialAt: Date | null;
  score: unknown;
  goalEvents: unknown;
  eventsHash: string;
};

export type HistoricalResultRevisionMatchInput = {
  legacyResult: {
    id: string;
    homeScore: number;
    awayScore: number;
    hasPenalty: boolean;
    homePenaltyScore: number | null;
    awayPenaltyScore: number | null;
    goals: HistoricalResultGoal[];
  };
  players: Array<{ id: string; userId: string | null; registrationId: string | null }>;
  homeRegistrationId: string | null;
  awayRegistrationId: string | null;
  sides: Array<{ id: string; sideKey: 'HOME' | 'AWAY' }>;
  participants: Array<{ id: string; userId: string | null; sideId: string }>;
  revisions: HistoricalResultRevision[];
};

type NormalizedGoal = {
  tournamentPlayerId?: string | null;
  id: string;
  team: 'home' | 'away';
  participantId: string | null;
  participantUserId: string | null;
  playerNameSnapshot: string | null;
  minute: number | null;
};

export type HistoricalResultParityEvidence = {
  method: 'SCORE_AND_LOSSLESS_GOAL_MULTIMAP';
  source: 'GOAL_EVENTS' | 'FROZEN_FIXTURE_SCORE' | 'EXPLICIT_IMPORT_ORIGIN';
  legacyGoals: NormalizedGoal[];
  canonicalGoals: NormalizedGoal[];
  matchedCandidateIds: string[];
};

export type HistoricalResultRevisionMatch = {
  revision: HistoricalResultRevision;
  evidence: HistoricalResultParityEvidence;
};

export class HistoricalResultRevisionMatchError extends Error {
  constructor(
    readonly code: 'NOT_FOUND' | 'GOAL_PARITY_UNRESOLVED' | 'AMBIGUOUS' | 'LEGACY_SCORE_INVALID',
    message: string,
  ) {
    super(message);
    this.name = 'HistoricalResultRevisionMatchError';
  }
}

function assertInteger(value: unknown, label: string): number {
  if (!Number.isInteger(value) || (value as number) < 0) {
    throw new HistoricalResultRevisionMatchError('LEGACY_SCORE_INVALID', `${label} must be a non-negative integer.`);
  }
  return value as number;
}

function legacyScore(input: HistoricalResultRevisionMatchInput): { home: number; away: number; penalties: { home: number; away: number } | null } {
  const home = assertInteger(input.legacyResult.homeScore, 'homeScore');
  const away = assertInteger(input.legacyResult.awayScore, 'awayScore');
  if (typeof input.legacyResult.hasPenalty !== 'boolean') throw new HistoricalResultRevisionMatchError('LEGACY_SCORE_INVALID', 'hasPenalty must be boolean.');
  if (!input.legacyResult.hasPenalty && (input.legacyResult.homePenaltyScore !== null || input.legacyResult.awayPenaltyScore !== null)) {
    throw new HistoricalResultRevisionMatchError('LEGACY_SCORE_INVALID', 'Penalty scores must be null when hasPenalty is false.');
  }
  if (input.legacyResult.hasPenalty && (input.legacyResult.homePenaltyScore === null || input.legacyResult.awayPenaltyScore === null)) {
    throw new HistoricalResultRevisionMatchError('LEGACY_SCORE_INVALID', 'Penalty scores are required when hasPenalty is true.');
  }
  return {
    home,
    away,
    penalties: input.legacyResult.hasPenalty
      ? { home: assertInteger(input.legacyResult.homePenaltyScore, 'homePenaltyScore'), away: assertInteger(input.legacyResult.awayPenaltyScore, 'awayPenaltyScore') }
      : null,
  };
}

function canonicalScore(value: unknown): { home: number; away: number; penalties: { home: number; away: number } | null } | null {
  try {
    const parsed = parseOfficialScore(value as Prisma.JsonValue);
    return { home: parsed.home, away: parsed.away, penalties: parsed.penalties ?? null };
  } catch {
    return null;
  }
}

function scoreMatches(actual: ReturnType<typeof legacyScore>, candidate: ReturnType<typeof canonicalScore>): boolean {
  return candidate !== null && candidate.home === actual.home && candidate.away === actual.away
    && (candidate.penalties?.home ?? null) === (actual.penalties?.home ?? null)
    && (candidate.penalties?.away ?? null) === (actual.penalties?.away ?? null);
}

function canonicalGoals(value: unknown, sides: HistoricalResultRevisionMatchInput['sides'], participants: Map<string, { userId: string | null; sideId: string }>): NormalizedGoal[] | null {
  if (!Array.isArray(value)) return null;
  const sideById = new Map(sides.map((side) => [side.id, side.sideKey.toLowerCase() as 'home' | 'away']));
  const result: NormalizedGoal[] = [];
  const seenIds = new Set<string>();
  for (const raw of value) {
    if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) return null;
    const goal = raw as Record<string, unknown>;
    if (typeof goal.id !== 'string' || seenIds.has(goal.id) || typeof goal.sideId !== 'string' || !sideById.has(goal.sideId)) return null;
    seenIds.add(goal.id);
    if (goal.participantId !== null && typeof goal.participantId !== 'string') return null;
    if (goal.minute !== null && (!Number.isInteger(goal.minute) || (goal.minute as number) < 0)) return null;
    if (goal.period !== null && (!Number.isInteger(goal.period) || (goal.period as number) < 1)) return null;
    if (goal.ownGoal !== false) return null;
    if (goal.playerNameSnapshot !== undefined && goal.playerNameSnapshot !== null && typeof goal.playerNameSnapshot !== 'string') return null;
    const participant = goal.participantId === null ? null : participants.get(goal.participantId as string);
    if (goal.participantId !== null && (participant == null || participant.sideId !== goal.sideId)) return null;
    const playerNameSnapshot = goal.participantId === null ? (goal.playerNameSnapshot as string | null | undefined) : null;
    if (goal.participantId === null && typeof playerNameSnapshot !== 'string') return null;
    result.push({ id: goal.id, team: sideById.get(goal.sideId)!, participantId: goal.participantId as string | null, participantUserId: participant?.userId ?? null, playerNameSnapshot: playerNameSnapshot ?? null, minute: goal.minute as number | null });
  }
  return result;
}

function frozenGoals(value: unknown): NormalizedGoal[] | null {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return null;
  const record = value as Record<string, unknown>;
  if (record.provenance !== 'TOURNAMENT_FIXTURE_RESULT' || !Array.isArray(record.goals)) return null;
  const result: NormalizedGoal[] = [];
  for (const [index, raw] of record.goals.entries()) {
    if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) return null;
    const goal = raw as Record<string, unknown>;
    if ((goal.team !== 'home' && goal.team !== 'away')
      || (goal.playerId !== null && typeof goal.playerId !== 'string')
      || typeof goal.playerName !== 'string'
      || (goal.minute !== null && (!Number.isInteger(goal.minute) || (goal.minute as number) < 0))) return null;
    // Frozen snapshots have no event UUID. Their array position is evidence,
    // not a fabricated GameEvent ID; repeated identical tuples remain distinct.
    result.push({
      id: String(index), team: goal.team,
      tournamentPlayerId: goal.playerId as string | null,
      participantId: null, participantUserId: null,
      playerNameSnapshot: goal.playerName, minute: goal.minute as number | null,
    });
  }
  return result;
}

function legacyGoals(input: HistoricalResultRevisionMatchInput, participants: Map<string, { userId: string | null; sideId: string }>): NormalizedGoal[] | null {
  const sideByRegistration = new Map([[input.homeRegistrationId, 'home' as const], [input.awayRegistrationId, 'away' as const]]);
  const playerById = new Map(input.players.map((player) => [player.id, player]));
  const sideById = new Map(input.sides.map((side) => [side.sideKey, side.id]));
  const result: NormalizedGoal[] = [];
  for (const goal of input.legacyResult.goals) {
    if (goal.minute !== null && (!Number.isInteger(goal.minute) || goal.minute < 0)) return null;
    if (goal.playerId === null) {
      result.push({ id: goal.id, team: goal.team, participantId: null, participantUserId: null, playerNameSnapshot: goal.playerName, minute: goal.minute });
      continue;
    }
    const player = playerById.get(goal.playerId);
    if (!player || player.userId === null || sideByRegistration.get(player.registrationId) !== goal.team) return null;
    const sideId = sideById.get(goal.team === 'home' ? 'HOME' : 'AWAY');
    const participant = [...participants.values()].find((candidate) => candidate.sideId === sideId && candidate.userId === player.userId);
    result.push({ id: goal.id, team: goal.team, participantId: participant ? [...participants.entries()].find(([, candidate]) => candidate === participant)?.[0] ?? null : null, participantUserId: player.userId, playerNameSnapshot: null, minute: goal.minute });
  }
  return result;
}

function isSameGoal(legacy: NormalizedGoal, canonical: NormalizedGoal): boolean {
  if ('tournamentPlayerId' in legacy || 'tournamentPlayerId' in canonical) {
    return legacy.team === canonical.team && legacy.minute === canonical.minute
      && legacy.tournamentPlayerId === canonical.tournamentPlayerId
      && legacy.playerNameSnapshot === canonical.playerNameSnapshot;
  }
  return legacy.team === canonical.team && legacy.minute === canonical.minute
    && (legacy.participantUserId !== null
      ? canonical.participantUserId === legacy.participantUserId && canonical.playerNameSnapshot === null
      : canonical.participantId === null && canonical.playerNameSnapshot === legacy.playerNameSnapshot);
}

export function selectHistoricalResultRevision(input: HistoricalResultRevisionMatchInput): HistoricalResultRevisionMatch {
  const score = legacyScore(input);
  const participantMap = new Map(input.participants.map((participant) => [participant.id, participant]));
  const eventLegacy = legacyGoals(input, participantMap);
  const legacy: NormalizedGoal[] = input.legacyResult.goals.map((goal) => ({ id: goal.id, team: goal.team, tournamentPlayerId: goal.playerId, participantId: null, participantUserId: null, playerNameSnapshot: goal.playerName, minute: goal.minute }));
  if (legacy.some((goal) => goal.minute !== null && (!Number.isInteger(goal.minute) || goal.minute < 0))) throw new HistoricalResultRevisionMatchError('GOAL_PARITY_UNRESOLVED', 'Legacy minute is invalid.');
  if (legacy.filter((goal) => goal.team === 'home').length > score.home || legacy.filter((goal) => goal.team === 'away').length > score.away) {
    throw new HistoricalResultRevisionMatchError('GOAL_PARITY_UNRESOLVED', 'Legacy goal evidence exceeds the recorded score.');
  }
  const candidates: HistoricalResultRevisionMatch[] = [];
  for (const revision of input.revisions) {
    if (revision.state !== 'OFFICIAL' || revision.officialAt === null || !scoreMatches(score, canonicalScore(revision.score))) continue;
    if (!Array.isArray(revision.goalEvents) && revision.goalEvents !== null) continue;
    let canonicalSource: HistoricalResultParityEvidence['source'] = Array.isArray(revision.goalEvents) ? 'GOAL_EVENTS' : 'FROZEN_FIXTURE_SCORE';
    const canonical = canonicalSource === 'GOAL_EVENTS' ? canonicalGoals(revision.goalEvents, input.sides, participantMap) : frozenGoals(revision.score);
    if (canonical === null) continue;
    const sourceLegacy = canonicalSource === 'GOAL_EVENTS' ? eventLegacy : legacy;
    if (sourceLegacy === null) continue;
    if (legacy.length === 0 && score.home + score.away > 0) {
      const raw = revision.score;
      if (typeof raw !== 'object' || raw === null || Array.isArray(raw)
        || !('provenance' in raw) || raw.provenance !== 'HISTORICAL_FIXTURE_RESULT_IMPORT'
        || !('originalResultId' in raw) || raw.originalResultId !== input.legacyResult.id
        || canonical.length !== 0) continue;
      canonicalSource = 'EXPLICIT_IMPORT_ORIGIN';
    }
    if (canonical.filter((goal) => goal.team === 'home').length > score.home || canonical.filter((goal) => goal.team === 'away').length > score.away) continue;
    const remaining = [...canonical];
    if (!sourceLegacy.every((goal) => {
      const index = remaining.findIndex((candidate) => isSameGoal(goal, candidate));
      if (index < 0) return false;
      remaining.splice(index, 1);
      return true;
    })) continue;
    if (canonicalSource === 'FROZEN_FIXTURE_SCORE' && remaining.length !== 0) continue;
    candidates.push({ revision, evidence: { method: 'SCORE_AND_LOSSLESS_GOAL_MULTIMAP', source: canonicalSource, legacyGoals: sourceLegacy, canonicalGoals: canonical, matchedCandidateIds: [revision.id] } });
  }
  if (candidates.length === 0) throw new HistoricalResultRevisionMatchError('NOT_FOUND', 'No unique official revision preserves the legacy score and goal evidence.');
  if (candidates.length > 1) throw new HistoricalResultRevisionMatchError('AMBIGUOUS', `Multiple official revisions preserve the legacy result: ${candidates.map((candidate) => candidate.revision.id).join(', ')}.`);
  return candidates[0];
}
