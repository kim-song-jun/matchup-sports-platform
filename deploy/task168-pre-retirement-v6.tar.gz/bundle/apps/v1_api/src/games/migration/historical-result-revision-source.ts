import type { Prisma } from '@prisma/client';
import type { HistoricalResultRevisionMatchInput } from './historical-result-revision-matcher';

export type HistoricalResultRevisionSourceClient = Pick<Prisma.TransactionClient, 'v1TournamentFixture' | 'v1Game'>;

export class HistoricalResultRevisionSourceError extends Error {
  constructor(readonly code: 'LEGACY_RESULT_NOT_FOUND' | 'GAME_OWNERSHIP_MISMATCH', message: string) {
    super(message);
    this.name = 'HistoricalResultRevisionSourceError';
  }
}

/** Read-only input shared by preflight and locked lineage capture. Capture's
 * caller must hold the Game and legacy source locks before relying on it. */
export async function loadHistoricalResultRevisionMatchInput(
  client: HistoricalResultRevisionSourceClient,
  fixtureId: string,
  gameId: string,
  storedRevisionId?: string,
): Promise<HistoricalResultRevisionMatchInput> {
  const [fixture, game] = await Promise.all([
    client.v1TournamentFixture.findUnique({
      where: { id: fixtureId },
      select: {
        id: true, homeRegistrationId: true, awayRegistrationId: true,
        result: { select: {
          id: true,
          homeScore: true, awayScore: true, hasPenalty: true,
          homePenaltyScore: true, awayPenaltyScore: true,
          goals: { orderBy: [{ createdAt: 'asc' }, { id: 'asc' }], select: {
            id: true, team: true, playerId: true, playerName: true, minute: true,
            player: { select: { id: true, userId: true, registrationId: true } },
          } },
        } },
      },
    }),
    client.v1Game.findUnique({
      where: { id: gameId },
      select: {
        sourceType: true, teamMatchId: true, tournamentFixtureId: true,
        sides: { select: { id: true, sideKey: true }, orderBy: { id: 'asc' } },
        participants: { select: { id: true, userId: true, sideId: true }, orderBy: { id: 'asc' } },
        resultRevisions: {
          ...(storedRevisionId === undefined ? {} : { where: { id: storedRevisionId } }),
          orderBy: [{ revision: 'asc' }, { id: 'asc' }],
          select: { id: true, revision: true, state: true, officialAt: true, score: true, goalEvents: true, eventsHash: true },
        },
      },
    }),
  ]);
  if (!fixture?.result) throw new HistoricalResultRevisionSourceError('LEGACY_RESULT_NOT_FOUND', `Fixture ${fixtureId} has no legacy result.`);
  const validLegacy = game?.sourceType === 'TOURNAMENT_FIXTURE' && game.tournamentFixtureId === fixtureId && (game.teamMatchId === null || game.teamMatchId === fixtureId);
  const validCanonical = (game?.sourceType === 'TEAM_MATCH' || game?.sourceType === 'COMPETITION_FIXTURE') && game.teamMatchId === fixtureId && (game.tournamentFixtureId === null || game.tournamentFixtureId === fixtureId);
  if (!game || (!validLegacy && !validCanonical)) throw new HistoricalResultRevisionSourceError('GAME_OWNERSHIP_MISMATCH', `Game ${gameId} does not belong to fixture ${fixtureId}.`);
  const { goals, ...result } = fixture.result;
  const players = new Map(goals.flatMap((goal) => goal.player ? [[goal.player.id, goal.player] as const] : []));
  return {
    legacyResult: { ...result, goals: goals.map(({ player: _player, ...goal }) => goal) },
    players: [...players.values()],
    homeRegistrationId: fixture.homeRegistrationId,
    awayRegistrationId: fixture.awayRegistrationId,
    sides: game.sides,
    participants: game.participants,
    revisions: game.resultRevisions,
  };
}
