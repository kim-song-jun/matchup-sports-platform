import type { V1FixtureAdvancementOutcome, V1FixtureTargetSide } from '@prisma/client';

export type TournamentAdvancementPreservationRow = {
  id: string;
  tournamentId: string;
  sourceTeamMatchId: string;
  sourceOutcome: V1FixtureAdvancementOutcome;
  targetTeamMatchId: string;
  targetSide: V1FixtureTargetSide;
  createdAt: Date;
};

export class TournamentAdvancementPreservationError extends Error {
  readonly code = 'ADVANCEMENT_PRESERVATION_MISMATCH';
  constructor(message: string) {
    super(message);
    this.name = 'TournamentAdvancementPreservationError';
  }
}

/**
 * Verifies the legacy edge set against canonical rows after backfill/cutover.
 * Canonical edges outside the legacy set are allowed: later bracket operations
 * may legitimately add them. Every legacy edge, however, must have exactly the
 * same identity, scope, outcome, side, and creation timestamp.
 */
export function assertTournamentAdvancementPreserved(
  legacyEdges: readonly TournamentAdvancementPreservationRow[],
  canonicalEdges: readonly TournamentAdvancementPreservationRow[],
): void {
  const expectedById = new Map<string, TournamentAdvancementPreservationRow>();
  for (const edge of legacyEdges) {
    if (expectedById.has(edge.id)) {
      throw new TournamentAdvancementPreservationError(`Legacy advancement edge ${edge.id} is duplicated.`);
    }
    expectedById.set(edge.id, edge);
  }

  const canonicalById = new Map<string, TournamentAdvancementPreservationRow>();
  for (const edge of canonicalEdges) {
    if (canonicalById.has(edge.id)) {
      throw new TournamentAdvancementPreservationError(`Canonical advancement edge ${edge.id} is duplicated.`);
    }
    canonicalById.set(edge.id, edge);
  }

  for (const [id, expected] of expectedById) {
    const actual = canonicalById.get(id);
    if (actual === undefined) {
      throw new TournamentAdvancementPreservationError(`Canonical advancement edge ${id} is missing.`);
    }
    if (
      actual.tournamentId !== expected.tournamentId
      || actual.sourceTeamMatchId !== expected.sourceTeamMatchId
      || actual.sourceOutcome !== expected.sourceOutcome
      || actual.targetTeamMatchId !== expected.targetTeamMatchId
      || actual.targetSide !== expected.targetSide
      || actual.createdAt.getTime() !== expected.createdAt.getTime()
    ) {
      throw new TournamentAdvancementPreservationError(`Canonical advancement edge ${id} differs from its legacy edge.`);
    }
  }
}
