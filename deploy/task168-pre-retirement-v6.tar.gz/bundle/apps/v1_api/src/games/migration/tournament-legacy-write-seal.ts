import { Prisma } from '@prisma/client';

const LEGACY_TABLES = [
  'v1_tournament_fixtures',
  'v1_tournament_fixture_results',
  'v1_tournament_fixture_goals',
  'v1_tournament_fixture_videos',
  'v1_tournament_fixture_advancement_edges',
] as const;

/**
 * Internal full-cutover finalizer. Call only after full dataset preservation and
 * audit sealing have succeeded, in the same Serializable transaction while the
 * maintenance claim gate is held. This prevents historical rows from diverging
 * again between the data cutover and the final schema retirement release.
 */
export async function lockTournamentLegacyWrites(tx: Prisma.TransactionClient): Promise<void> {
  // Identifiers are a closed source-code list, never caller input. Hold every
  // table through commit so writes cannot slip between validation and sealing.
  for (const table of LEGACY_TABLES) {
    await tx.$executeRaw(Prisma.sql`LOCK TABLE ${Prisma.raw(`"${table}"`)} IN ACCESS EXCLUSIVE MODE`);
  }
}

export async function sealTournamentLegacyWrites(tx: Prisma.TransactionClient): Promise<void> {
  await tx.$executeRaw`
    CREATE OR REPLACE FUNCTION v1_reject_retired_tournament_fixture_write()
    RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      -- FK SET NULL/CASCADE may issue an UPDATE/DELETE that matches no legacy
      -- rows. Let nested statements reach the row guard; real mutations still
      -- fail there. Direct legacy statements and every TRUNCATE remain blocked.
      IF TG_LEVEL = 'STATEMENT' AND TG_OP IN ('UPDATE', 'DELETE') AND pg_trigger_depth() > 1 THEN
        RETURN NULL;
      END IF;
      RAISE EXCEPTION 'tournament_fixture_retired: % on % is forbidden', TG_OP, TG_TABLE_NAME
        USING ERRCODE = '55000';
    END;
    $$
  `;
  for (const table of LEGACY_TABLES) {
    await tx.$executeRaw(Prisma.sql`
      CREATE OR REPLACE TRIGGER v1_tournament_fixture_retired_write
      BEFORE INSERT OR UPDATE OR DELETE OR TRUNCATE ON ${Prisma.raw(`"${table}"`)}
      FOR EACH STATEMENT EXECUTE FUNCTION v1_reject_retired_tournament_fixture_write()
    `);
    await tx.$executeRaw(Prisma.sql`
      ALTER TABLE ${Prisma.raw(`"${table}"`)} ENABLE ALWAYS TRIGGER v1_tournament_fixture_retired_write
    `);
    await tx.$executeRaw(Prisma.sql`
      CREATE OR REPLACE TRIGGER v1_tournament_fixture_retired_row_write
      BEFORE UPDATE OR DELETE ON ${Prisma.raw(`"${table}"`)}
      FOR EACH ROW EXECUTE FUNCTION v1_reject_retired_tournament_fixture_write()
    `);
    await tx.$executeRaw(Prisma.sql`
      ALTER TABLE ${Prisma.raw(`"${table}"`)} ENABLE ALWAYS TRIGGER v1_tournament_fixture_retired_row_write
    `);
  }
  // Historical tables remain readable until DROP. Reject new incoming links as
  // well, otherwise an old client could reattach a Game/staff/audit to them.
  await tx.$executeRaw`
    CREATE OR REPLACE FUNCTION v1_reject_retired_tournament_fixture_link()
    RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      IF TG_TABLE_NAME = 'v1_games' THEN
        IF NEW.tournament_fixture_id IS NOT NULL OR NEW.source_type::text = 'TOURNAMENT_FIXTURE' THEN
          RAISE EXCEPTION 'tournament_fixture_retired: legacy game source is forbidden' USING ERRCODE = '55000';
        END IF;
      ELSIF NEW.fixture_id IS NOT NULL THEN
        RAISE EXCEPTION 'tournament_fixture_retired: legacy fixture scope is forbidden' USING ERRCODE = '55000';
      END IF;
      RETURN NEW;
    END;
    $$
  `;
  for (const table of ['v1_games', 'v1_tournament_staff_fixture_scopes', 'v1_operation_audits'] as const) {
    await tx.$executeRaw(Prisma.sql`
      CREATE OR REPLACE TRIGGER v1_000_tournament_fixture_retired_link
      BEFORE INSERT OR UPDATE ON ${Prisma.raw(`"${table}"`)}
      FOR EACH ROW EXECUTE FUNCTION v1_reject_retired_tournament_fixture_link()
    `);
    await tx.$executeRaw(Prisma.sql`
      ALTER TABLE ${Prisma.raw(`"${table}"`)} ENABLE ALWAYS TRIGGER v1_000_tournament_fixture_retired_link
    `);
  }
}
