import { Prisma } from '@prisma/client';

type AuditSealErrorCode = 'AUDIT_SEAL_BLOCKED_LEGACY_FIXTURE_SCOPES' | 'AUDIT_SEAL_TRIGGER_MISSING' | 'AUDIT_SEAL_CUTOVER_INCOMPLETE';

export class TournamentOperationAuditSealError extends Error {
  readonly code: AuditSealErrorCode;

  constructor(code: AuditSealErrorCode, readonly legacyFixtureScopeCount = 0) {
    super(code === 'AUDIT_SEAL_TRIGGER_MISSING'
      ? 'Cannot seal operation audits because the append-only trigger is missing or disabled.'
      : code === 'AUDIT_SEAL_CUTOVER_INCOMPLETE' ? 'Cannot seal operation audits before the fixture cutover is complete.'
      : `Cannot seal operation audits while ${legacyFixtureScopeCount} legacy fixture scope(s) remain.`);
    this.code = code;
    this.name = 'TournamentOperationAuditSealError';
  }
}

/**
 * Seals the append-only audit trigger after the operational fixture cutover.
 * Internal full-cutover finalizer: the caller must hold the full-cutover locks
 * in its Serializable transaction and keep the maintenance claim gate held
 * through commit. This is not a standalone operational entry point.
 */
export async function sealTournamentOperationAudits(tx: Prisma.TransactionClient): Promise<{ sealed: true }> {
  // Serialize the precondition check with every audit writer before inspecting
  // legacy scopes. The full cutover takes this same lock before its fixture lock.
  await tx.$executeRaw`LOCK TABLE "v1_operation_audits" IN SHARE ROW EXCLUSIVE MODE`;
  await tx.$executeRaw`LOCK TABLE "v1_tournament_fixtures" IN SHARE ROW EXCLUSIVE MODE`;
  const [trigger] = await tx.$queryRaw<Array<{ enabled: string; functionName: string }>>`
    SELECT t.tgenabled::text AS enabled, p.proname AS "functionName"
    FROM pg_trigger t
    JOIN pg_proc p ON p.oid = t.tgfoid
    WHERE t.tgrelid = 'v1_operation_audits'::regclass
      AND t.tgname = 'v1_operation_audits_append_only'
      AND NOT t.tgisinternal
      AND t.tgfoid = 'v1_reject_operation_audit_mutation()'::regprocedure
      AND t.tgtype = 27
      AND t.tgqual IS NULL
  `;
  if (trigger?.enabled !== 'O' || trigger.functionName !== 'v1_reject_operation_audit_mutation') {
    throw new TournamentOperationAuditSealError('AUDIT_SEAL_TRIGGER_MISSING');
  }
  const legacyFixtureScopeCount = await tx.v1OperationAudit.count({
    where: { fixtureId: { not: null } },
  });
  if (legacyFixtureScopeCount !== 0) {
    throw new TournamentOperationAuditSealError('AUDIT_SEAL_BLOCKED_LEGACY_FIXTURE_SCOPES', legacyFixtureScopeCount);
  }

  const [readiness] = await tx.$queryRaw<{ ready: boolean }[]>`
    SELECT NOT EXISTS (
      SELECT 1 FROM v1_tournament_fixtures f
      LEFT JOIN v1_team_matches m ON m.id = f.id AND m.tournament_id = f.tournament_id
        AND m.deleted_at IS NULL AND m.league_id IS NULL
      LEFT JOIN v1_tournament_match_details d ON d.team_match_id = m.id AND d.tournament_id = f.tournament_id
      LEFT JOIN v1_games g ON g.team_match_id = m.id AND g.source_type = 'TEAM_MATCH'
      WHERE m.id IS NULL OR d.team_match_id IS NULL OR g.id IS NULL
    ) AND NOT EXISTS (
      SELECT 1 FROM v1_games WHERE tournament_fixture_id IS NOT NULL OR source_type = 'TOURNAMENT_FIXTURE'
    ) AND NOT EXISTS (
      SELECT 1 FROM v1_tournament_staff_fixture_scopes WHERE fixture_id IS NOT NULL
    ) AS ready
  `;
  if (!readiness?.ready) throw new TournamentOperationAuditSealError('AUDIT_SEAL_CUTOVER_INCOMPLETE');

  await tx.$executeRaw`
    CREATE OR REPLACE FUNCTION v1_reject_operation_audit_mutation()
    RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      RAISE EXCEPTION 'v1_operation_audits_append_only: % is forbidden', TG_OP
        USING ERRCODE = '55000';
    END;
    $$;
  `;
  return { sealed: true };
}
