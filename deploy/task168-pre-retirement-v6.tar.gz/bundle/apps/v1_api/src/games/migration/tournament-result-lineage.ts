import { createHash } from 'node:crypto';
import { Prisma } from '@prisma/client';
import { parseOfficialScore } from '../../game-operations/parse-official-score';
import { selectHistoricalResultRevision } from './historical-result-revision-matcher';
import { loadHistoricalResultRevisionMatchInput } from './historical-result-revision-source';

export class TournamentResultLineageError extends Error {
  constructor(
    readonly code:
      | 'LEGACY_RESULT_NOT_FOUND'
      | 'CANONICAL_GAME_REQUIRED'
      | 'CANONICAL_OWNERSHIP_MISMATCH'
      | 'OFFICIAL_REVISION_REQUIRED'
      | 'LINEAGE_SNAPSHOT_MISMATCH',
    message: string,
  ) {
    super(message);
    this.name = 'TournamentResultLineageError';
  }
}

export interface CaptureTournamentResultLineageInput {
  originalFixtureId: string;
  teamMatchId: string;
  gameId: string;
  officialRevisionId: string;
}

export interface TournamentResultLineageCapture {
  created: boolean;
  lineageId: string;
  originalResultId: string;
  snapshotHash: string;
}

type Tx = Prisma.TransactionClient;

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const record = value as Record<string, unknown>;
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(',')}}`;
}

function snapshotHash(snapshot: unknown): string {
  return createHash('sha256').update(stableStringify(snapshot), 'utf8').digest('hex');
}

function jsonInput(value: unknown): Prisma.InputJsonValue {
  return value as Prisma.InputJsonValue;
}

export async function captureTournamentResultLineage(
  tx: Tx,
  input: CaptureTournamentResultLineageInput,
): Promise<TournamentResultLineageCapture> {
  if (input.originalFixtureId !== input.teamMatchId) {
    throw new TournamentResultLineageError(
      'CANONICAL_OWNERSHIP_MISMATCH',
      `Legacy fixture ${input.originalFixtureId} cannot be captured for TeamMatch ${input.teamMatchId}; Task 168 requires the preserved UUID to remain unchanged.`,
    );
  }

  // Keep the migration lock order aligned with source cutover: Game, then the
  // legacy fixture/result/goal rows. This prevents a result writer from taking
  // the fixture lock while the lineage capture owns the Game lock.
  await tx.$queryRaw`SELECT id FROM "v1_games" WHERE id = ${input.gameId} FOR UPDATE`;
  await tx.$queryRaw`SELECT id FROM "v1_tournament_fixtures" WHERE id = ${input.originalFixtureId} FOR UPDATE`;
  await tx.$queryRaw`SELECT id FROM "v1_tournament_fixture_results" WHERE fixture_id = ${input.originalFixtureId} FOR UPDATE`;
  await tx.$queryRaw`
    SELECT goal.id
    FROM "v1_tournament_fixture_goals" goal
    INNER JOIN "v1_tournament_fixture_results" result ON result.id = goal.fixture_result_id
    WHERE result.fixture_id = ${input.originalFixtureId}
    ORDER BY goal.id
    FOR UPDATE
  `;

  const [teamMatch, game, revision, fixture, result] = await Promise.all([
    tx.v1TeamMatch.findUnique({
      where: { id: input.teamMatchId },
      select: { id: true, tournamentId: true, tournamentDetails: { select: { tournamentId: true } } },
    }),
    tx.v1Game.findUnique({
      where: { id: input.gameId },
      select: { id: true, sourceType: true, teamMatchId: true, tournamentFixtureId: true, currentOfficialRevisionId: true },
    }),
    tx.v1GameResultRevision.findFirst({
      where: { id: input.officialRevisionId, gameId: input.gameId },
      select: { id: true, gameId: true, state: true, officialAt: true, score: true, eventsHash: true, goalEvents: true },
    }),
    tx.v1TournamentFixture.findUnique({
      where: { id: input.originalFixtureId },
      select: { id: true, tournamentId: true },
    }),
    tx.v1TournamentFixtureResult.findUnique({
      where: { fixtureId: input.originalFixtureId },
      include: { goals: { orderBy: [{ createdAt: 'asc' }, { id: 'asc' }] } },
    }),
  ]);

  if (!result) {
    throw new TournamentResultLineageError('LEGACY_RESULT_NOT_FOUND', `Legacy fixture result ${input.originalFixtureId} does not exist.`);
  }
  if (!fixture || fixture.tournamentId !== teamMatch?.tournamentId) {
    throw new TournamentResultLineageError('CANONICAL_OWNERSHIP_MISMATCH', `Legacy fixture ${input.originalFixtureId} is not owned by the canonical TeamMatch tournament.`);
  }
  const existing = await tx.v1TournamentResultLineage.findUnique({ where: { originalResultId: result.id } });
  if (!teamMatch || teamMatch.tournamentId === null || teamMatch.tournamentDetails?.tournamentId !== teamMatch.tournamentId) {
    throw new TournamentResultLineageError('CANONICAL_OWNERSHIP_MISMATCH', `TeamMatch ${input.teamMatchId} is not a complete tournament-owned canonical match.`);
  }
  if (!game || game.sourceType !== 'TEAM_MATCH' || game.teamMatchId !== input.teamMatchId || game.tournamentFixtureId !== null) {
    throw new TournamentResultLineageError('CANONICAL_GAME_REQUIRED', `Game ${input.gameId} is not the canonical TeamMatch game for ${input.teamMatchId}.`);
  }
  if (!revision || revision.state !== 'OFFICIAL' || revision.officialAt === null) {
    throw new TournamentResultLineageError('OFFICIAL_REVISION_REQUIRED', `Game ${input.gameId} has no requested historical official revision ${input.officialRevisionId}.`);
  }

  let officialScore: ReturnType<typeof parseOfficialScore>;
  try {
    officialScore = parseOfficialScore(revision.score);
  } catch (error) {
    throw new TournamentResultLineageError('OFFICIAL_REVISION_REQUIRED', `Official revision ${revision.id} has an invalid score: ${error instanceof Error ? error.message : String(error)}`);
  }
  const legacyPenalties = result.hasPenalty
    ? { home: result.homePenaltyScore, away: result.awayPenaltyScore }
    : undefined;
  const hasValidLegacyPenalties = result.hasPenalty
    ? Number.isInteger(result.homePenaltyScore) && result.homePenaltyScore !== null && result.homePenaltyScore >= 0
      && Number.isInteger(result.awayPenaltyScore) && result.awayPenaltyScore !== null && result.awayPenaltyScore >= 0
    : result.homePenaltyScore === null && result.awayPenaltyScore === null;
  if (
    !hasValidLegacyPenalties
    ||
    officialScore.home !== result.homeScore
    || officialScore.away !== result.awayScore
    || (officialScore.penalties?.home ?? null) !== (legacyPenalties?.home ?? null)
    || (officialScore.penalties?.away ?? null) !== (legacyPenalties?.away ?? null)
  ) {
    throw new TournamentResultLineageError('LINEAGE_SNAPSHOT_MISMATCH', `Official revision ${revision.id} does not preserve the legacy result score for ${result.id}.`);
  }

  // First capture proves a unique match across the complete official history.
  // Reruns validate the immutable original binding even if later corrections
  // repeat its score or the current pointer now references a VOID revision.
  const matched = selectHistoricalResultRevision(await loadHistoricalResultRevisionMatchInput(
    tx, input.originalFixtureId, input.gameId, existing?.officialRevisionId,
  ));
  if (matched.revision.id !== input.officialRevisionId) {
    throw new TournamentResultLineageError('LINEAGE_SNAPSHOT_MISMATCH', `Requested revision ${input.officialRevisionId} is not the verified original revision ${matched.revision.id}.`);
  }

  const snapshot = {
    originalResultId: result.id,
    originalFixtureId: input.originalFixtureId,
    originalFixtureTournamentId: fixture.tournamentId,
    homeScore: result.homeScore,
    awayScore: result.awayScore,
    hasPenalty: result.hasPenalty,
    homePenaltyScore: result.homePenaltyScore,
    awayPenaltyScore: result.awayPenaltyScore,
    note: result.note,
    recordedByAdminUserId: result.recordedByAdminUserId,
    recordedAt: result.recordedAt.toISOString(),
    createdAt: result.createdAt.toISOString(),
    updatedAt: result.updatedAt.toISOString(),
    goals: result.goals.map((goal) => ({
      id: goal.id,
      team: goal.team,
      playerId: goal.playerId,
      playerName: goal.playerName,
      minute: goal.minute,
      createdAt: goal.createdAt.toISOString(),
    })),
    officialScore,
    officialEventsHash: revision.eventsHash,
    canonicalGoalEvents: revision.goalEvents,
    parity: matched.evidence,
  };
  const hash = snapshotHash(snapshot);
  const officialScoreHash = snapshotHash(officialScore);
  if (existing) {
    if (
      existing.originalFixtureId !== input.originalFixtureId
      || existing.originalFixtureTournamentId !== fixture.tournamentId
      || existing.tournamentId !== teamMatch.tournamentId
      || existing.teamMatchId !== input.teamMatchId
      || existing.gameId !== input.gameId
      || existing.officialRevisionId !== input.officialRevisionId
      || existing.snapshotHash !== hash
      || existing.officialEventsHash !== revision.eventsHash
      || existing.officialScoreHash !== officialScoreHash
    ) {
      throw new TournamentResultLineageError('LINEAGE_SNAPSHOT_MISMATCH', `Lineage ${existing.id} does not match the current immutable legacy result ${result.id}.`);
    }
    return { created: false, lineageId: existing.id, originalResultId: result.id, snapshotHash: hash };
  }

  const created = await tx.v1TournamentResultLineage.create({
    data: {
      originalResultId: result.id,
      originalFixtureId: input.originalFixtureId,
      originalFixtureTournamentId: fixture.tournamentId,
      tournamentId: teamMatch.tournamentId,
      teamMatchId: input.teamMatchId,
      gameId: input.gameId,
      officialRevisionId: input.officialRevisionId,
      officialScore: jsonInput(officialScore),
      officialScoreHash,
      officialEventsHash: revision.eventsHash,
      homeScore: result.homeScore,
      awayScore: result.awayScore,
      hasPenalty: result.hasPenalty,
      homePenaltyScore: result.homePenaltyScore,
      awayPenaltyScore: result.awayPenaltyScore,
      note: result.note,
      recordedByAdminUserId: result.recordedByAdminUserId,
      originalRecordedAt: result.recordedAt,
      originalCreatedAt: result.createdAt,
      originalUpdatedAt: result.updatedAt,
      snapshot: jsonInput(snapshot),
      snapshotHash: hash,
    },
    select: { id: true },
  });
  return { created: true, lineageId: created.id, originalResultId: result.id, snapshotHash: hash };
}
