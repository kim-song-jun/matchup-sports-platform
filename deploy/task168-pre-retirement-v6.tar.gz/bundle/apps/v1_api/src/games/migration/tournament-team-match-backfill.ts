import { Prisma, type PrismaClient, V1FixtureAdvancementOutcome, V1FixtureTargetSide, V1GameSideKey, V1TeamMatchStatus, V1TournamentFixtureStatus } from '@prisma/client';
import { preflightTournamentFixtureMigration, type TournamentTeamMatchPreflightClient, type TournamentTeamMatchPreflightReport } from './tournament-team-match-preflight';
import { PrismaService } from '../../prisma/prisma.service';
import { lockVideoUrl } from '../video-url-lock';
import { assertTournamentAdvancementPreserved, type TournamentAdvancementPreservationRow } from './tournament-advancement-preservation';

export type TournamentTeamMatchBackfillOptions = {
  tournamentIds?: readonly string[];
  fixtureIds?: readonly string[];
  topologyFixtureIds?: readonly string[];
};

type BackfillClient = PrismaClient | Prisma.TransactionClient;

type FixtureRow = {
  id: string;
  tournamentId: string;
  competitionConfigVersionId: string | null;
  groupId: string | null;
  round: string;
  fixtureNumber: number;
  legNumber: number;
  parentFixtureId: string | null;
  homeRegistrationId: string | null;
  awayRegistrationId: string | null;
  scheduledAt: Date | null;
  fieldId: string | null;
  venue: string | null;
  status: V1TournamentFixtureStatus;
  createdAt: Date;
  updatedAt: Date;
  tournament: { id: string; title: string; sportId: string };
  homeRegistration: { teamId: string | null } | null;
  awayRegistration: { teamId: string | null } | null;
  game: { id: string; teamMatchId: string | null; tournamentFixtureId: string | null; competitionConfigVersionId: string; sides: Array<{ sideKey: V1GameSideKey; teamId: string | null }> } | null;
  advancementSources: Array<{ id: string; sourceOutcome: V1FixtureAdvancementOutcome; targetFixtureId: string; targetSide: V1FixtureTargetSide; createdAt: Date }>;
};

type ExistingDetails = {
  teamMatchId: string;
  tournamentId: string;
  groupId: string | null;
  round: string;
  fixtureNumber: number;
  legNumber: number;
  parentTeamMatchId: string | null;
  homeRegistrationId: string | null;
  awayRegistrationId: string | null;
};

type ExistingEdge = {
  id: string;
  tournamentId: string;
  sourceTeamMatchId: string;
  sourceOutcome: V1FixtureAdvancementOutcome;
  targetTeamMatchId: string;
  targetSide: V1FixtureTargetSide;
  createdAt: Date;
};

export type TournamentTeamMatchBackfillSnapshot = {
  teamMatchIds: string[];
  detailIds: string[];
  advancementEdgeIds: string[];
  linkedGameIds: string[];
  legacyFingerprints: string[];
};

export type TournamentTeamMatchBackfillResult = {
  preflight: TournamentTeamMatchPreflightReport;
  counts: {
    fixturesConsidered: number;
    teamMatchesCreated: number;
    teamMatchesAlreadyPresent: number;
    detailsCreated: number;
    detailsAlreadyPresent: number;
    gamesLinked: number;
    advancementEdgesCreated: number;
    advancementEdgesAlreadyPresent: number;
    videosCreated: number;
    videosAlreadyPresent: number;
  };
  before: TournamentTeamMatchBackfillSnapshot;
  after: TournamentTeamMatchBackfillSnapshot;
};

export class TournamentTeamMatchBackfillError extends Error {
  constructor(message: string, readonly report?: TournamentTeamMatchPreflightReport) {
    super(message);
    this.name = 'TournamentTeamMatchBackfillError';
  }
}

function unique(values: readonly string[]): string[] {
  return [...new Set(values.filter(Boolean))];
}

export function fixtureStatusToTeamMatchStatus(status: V1TournamentFixtureStatus): V1TeamMatchStatus {
  switch (status) {
    case 'completed':
      return V1TeamMatchStatus.completed;
    case 'cancelled':
      return V1TeamMatchStatus.cancelled;
    case 'scheduled':
    case 'in_progress':
      return V1TeamMatchStatus.matched;
  }
}

function derivedTitle(fixture: FixtureRow): string {
  return `${fixture.tournament.title} · ${fixture.round} ${fixture.fixtureNumber}`;
}

export function resolveTournamentTeamIds(input: {
  fixtureId: string;
  homeFromGame: string | null;
  awayFromGame: string | null;
  homeFromRegistration: string | null;
  awayFromRegistration: string | null;
}): { homeTeamId: string | null; awayTeamId: string | null } {
  const { fixtureId, homeFromGame, awayFromGame, homeFromRegistration, awayFromRegistration } = input;
  if (homeFromGame !== null && homeFromRegistration !== null && homeFromGame !== homeFromRegistration) {
    throw new TournamentTeamMatchBackfillError(`Fixture ${fixtureId} has conflicting home team IDs.`);
  }
  if (awayFromGame !== null && awayFromRegistration !== null && awayFromGame !== awayFromRegistration) {
    throw new TournamentTeamMatchBackfillError(`Fixture ${fixtureId} has conflicting away team IDs.`);
  }
  return {
    homeTeamId: homeFromGame ?? homeFromRegistration,
    awayTeamId: awayFromGame ?? awayFromRegistration,
  };
}

function resolvedTeamIds(fixture: FixtureRow): { homeTeamId: string | null; awayTeamId: string | null } {
  const sideTeamId = (sideKey: V1GameSideKey): string | null => fixture.game?.sides.find((side) => side.sideKey === sideKey)?.teamId ?? null;
  return resolveTournamentTeamIds({
    fixtureId: fixture.id,
    homeFromGame: sideTeamId(V1GameSideKey.HOME),
    awayFromGame: sideTeamId(V1GameSideKey.AWAY),
    homeFromRegistration: fixture.homeRegistration?.teamId ?? null,
    awayFromRegistration: fixture.awayRegistration?.teamId ?? null,
  });
}

function asPreflightClient(tx: Prisma.TransactionClient): TournamentTeamMatchPreflightClient {
  return tx;
}

function boundedBackfillScope(options: TournamentTeamMatchBackfillOptions) {
  const tournamentIds = unique(options.tournamentIds ?? []);
  const fixtureIds = unique(options.fixtureIds ?? []);
  if (tournamentIds.length === 0 && fixtureIds.length === 0) {
    throw new TournamentTeamMatchBackfillError('Provide tournamentIds or fixtureIds; an unbounded backfill is not allowed.');
  }
  return { tournamentIds, fixtureIds };
}

async function selectFixtureIds(client: BackfillClient, options: TournamentTeamMatchBackfillOptions): Promise<string[]> {
  const { tournamentIds, fixtureIds } = boundedBackfillScope(options);
  const where = tournamentIds.length > 0 && fixtureIds.length > 0
    ? { AND: [{ tournamentId: { in: tournamentIds } }, { id: { in: fixtureIds } }] }
    : tournamentIds.length > 0 ? { tournamentId: { in: tournamentIds } } : { id: { in: fixtureIds } };
  const rows = await client.v1TournamentFixture.findMany({
    where,
    select: { id: true },
    orderBy: { id: 'asc' },
  });
  const selected = rows.map((row) => row.id);
  if (tournamentIds.length > 0 && fixtureIds.length > 0 && selected.length !== fixtureIds.length) {
    throw new TournamentTeamMatchBackfillError('The explicit fixtureIds are not all inside the requested tournamentIds intersection.');
  }
  if (selected.length === 0) throw new TournamentTeamMatchBackfillError('The explicit backfill scope contains no fixtures.');
  return selected;
}

async function lockRows(tx: Prisma.TransactionClient, fixtureIds: string[]): Promise<string[]> {
  if (fixtureIds.length === 0) return [];
  await tx.$queryRaw`SELECT id FROM "v1_tournament_fixtures" WHERE id IN (${Prisma.join(fixtureIds)}) FOR UPDATE`;
  const [gameRows, canonicalGameRows] = await Promise.all([
    tx.v1TournamentFixture.findMany({ where: { id: { in: fixtureIds } }, select: { game: { select: { id: true } } } }),
    tx.v1TeamMatch.findMany({ where: { id: { in: fixtureIds } }, select: { game: { select: { id: true } } } }),
  ]);
  const gameIds = unique([
    ...gameRows.flatMap((row) => (row.game ? [row.game.id] : [])),
    ...canonicalGameRows.flatMap((row) => (row.game ? [row.game.id] : [])),
  ]);
  if (gameIds.length > 0) {
    await tx.$queryRaw`SELECT id FROM "v1_games" WHERE id IN (${Prisma.join(gameIds)}) FOR UPDATE`;
  }
  return gameIds;
}

async function loadFixtures(tx: Prisma.TransactionClient, fixtureIds: string[]): Promise<FixtureRow[]> {
  if (fixtureIds.length === 0) return [];
  const fixtures = await tx.v1TournamentFixture.findMany({
    where: { id: { in: fixtureIds } },
    orderBy: [{ tournamentId: 'asc' }, { id: 'asc' }],
    select: {
      id: true,
      tournamentId: true,
      competitionConfigVersionId: true,
      groupId: true,
      round: true,
      fixtureNumber: true,
      legNumber: true,
      parentFixtureId: true,
      homeRegistrationId: true,
      awayRegistrationId: true,
      scheduledAt: true,
      fieldId: true,
      venue: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      tournament: { select: { id: true, title: true, sportId: true } },
      homeRegistration: { select: { teamId: true } },
      awayRegistration: { select: { teamId: true } },
      game: { select: { id: true, teamMatchId: true, tournamentFixtureId: true, competitionConfigVersionId: true, sides: { select: { sideKey: true, teamId: true } } } },
      advancementSources: { select: { id: true, sourceOutcome: true, targetFixtureId: true, targetSide: true, createdAt: true }, orderBy: { id: 'asc' } },
    },
  });
  const missingGameFixtureIds = fixtures.filter((fixture) => fixture.game === null).map((fixture) => fixture.id);
  if (missingGameFixtureIds.length === 0) return fixtures as FixtureRow[];
  const canonicalGames = await tx.v1TeamMatch.findMany({
    where: { id: { in: missingGameFixtureIds } },
    select: { id: true, game: { select: { id: true, teamMatchId: true, tournamentFixtureId: true, competitionConfigVersionId: true, sides: { select: { sideKey: true, teamId: true } } } } },
  });
  const gameByMatchId = new Map(canonicalGames.filter((row) => row.game !== null).map((row) => [row.id, row.game!]));
  return fixtures.map((fixture) => ({ ...fixture, game: fixture.game ?? gameByMatchId.get(fixture.id) ?? null })) as FixtureRow[];
}

async function snapshot(tx: Prisma.TransactionClient, fixtureIds: string[]): Promise<TournamentTeamMatchBackfillSnapshot> {
  if (fixtureIds.length === 0) return { teamMatchIds: [], detailIds: [], advancementEdgeIds: [], linkedGameIds: [], legacyFingerprints: [] };
  const [teamMatches, details, edges, games, legacyRows, canonicalLegacyRows] = await Promise.all([
    tx.v1TeamMatch.findMany({ where: { id: { in: fixtureIds } }, select: { id: true }, orderBy: { id: 'asc' } }),
    tx.v1TournamentMatchDetails.findMany({ where: { teamMatchId: { in: fixtureIds } }, select: { teamMatchId: true }, orderBy: { teamMatchId: 'asc' } }),
    tx.v1TournamentMatchAdvancementEdge.findMany({ where: { OR: [{ sourceTeamMatchId: { in: fixtureIds } }, { targetTeamMatchId: { in: fixtureIds } }] }, select: { id: true }, orderBy: { id: 'asc' } }),
    tx.v1Game.findMany({ where: { teamMatchId: { in: fixtureIds } }, select: { id: true }, orderBy: { id: 'asc' } }),
    tx.v1TournamentFixture.findMany({
      where: { id: { in: fixtureIds } },
      select: {
        id: true,
        result: { select: { id: true, goals: { select: { id: true }, orderBy: { id: 'asc' } } } },
        game: {
          select: {
            id: true,
            teamMatchId: true,
            tournamentFixtureId: true,
            periods: { select: { id: true }, orderBy: { id: 'asc' } },
            lineups: { select: { id: true }, orderBy: { id: 'asc' } },
            participants: { select: { id: true }, orderBy: { id: 'asc' } },
            events: { select: { id: true, payloadHash: true }, orderBy: { id: 'asc' } },
            resultRevisions: { select: { id: true, eventsHash: true, officialFact: { select: { id: true, eventsHash: true } } }, orderBy: { id: 'asc' } },
          },
        },
      },
    }),
    tx.v1TeamMatch.findMany({
      where: { id: { in: fixtureIds } },
      select: {
        id: true,
        game: {
          select: {
            id: true,
            teamMatchId: true,
            tournamentFixtureId: true,
            periods: { select: { id: true }, orderBy: { id: 'asc' } },
            lineups: { select: { id: true }, orderBy: { id: 'asc' } },
            participants: { select: { id: true }, orderBy: { id: 'asc' } },
            events: { select: { id: true, payloadHash: true }, orderBy: { id: 'asc' } },
            resultRevisions: { select: { id: true, eventsHash: true, officialFact: { select: { id: true, eventsHash: true } } }, orderBy: { id: 'asc' } },
          },
        },
      },
    }),
  ]);
  const canonicalGameByFixtureId = new Map(canonicalLegacyRows.filter((row) => row.game !== null).map((row) => [row.id, row.game!]));
  const legacyFingerprints = legacyRows.flatMap((row) => {
    const values = [`fixture:${row.id}`, ...(row.result ? [`fixture-result:${row.result.id}`, ...row.result.goals.map((goal) => `fixture-goal:${goal.id}`)] : [])];
    const game = row.game ?? canonicalGameByFixtureId.get(row.id) ?? null;
    if (game === null) return values;
    // teamMatchId is the intentional new link; the legacy game identity and
    // fixture source link are the conserved values.
    values.push(`game:${game.id}:${game.tournamentFixtureId ?? ''}`);
    values.push(...game.periods.map((period) => `period:${period.id}`));
    values.push(...game.lineups.map((lineup) => `lineup:${lineup.id}`));
    values.push(...game.participants.map((participant) => `participant:${participant.id}`));
    values.push(...game.events.map((event) => `event:${event.id}:${event.payloadHash}`));
    values.push(...game.resultRevisions.flatMap((revision) => [`revision:${revision.id}:${revision.eventsHash}`, ...(revision.officialFact ? [`fact:${revision.officialFact.id}:${revision.officialFact.eventsHash}`] : [])]));
    return values;
  }).sort();
  return {
    teamMatchIds: teamMatches.map((row) => row.id),
    detailIds: details.map((row) => row.teamMatchId),
    advancementEdgeIds: edges.map((row) => row.id),
    linkedGameIds: games.map((row) => row.id),
    legacyFingerprints,
  };
}

function assertPreflightReady(report: TournamentTeamMatchPreflightReport): void {
  if (report.status !== 'READY') {
    throw new TournamentTeamMatchBackfillError(`Tournament TeamMatch backfill preflight is ${report.status}; no writes were applied.`, report);
  }
}

function assertClosedTopology(fixtures: FixtureRow[], topologyFixtureIds?: readonly string[]): void {
  const ids = new Set(topologyFixtureIds ?? fixtures.map((fixture) => fixture.id));
  for (const fixture of fixtures) {
    if (fixture.parentFixtureId !== null && !ids.has(fixture.parentFixtureId)) {
      throw new TournamentTeamMatchBackfillError(`Fixture ${fixture.id} has a parent outside the bounded scope.`);
    }
    for (const edge of fixture.advancementSources) {
      if (!ids.has(edge.targetFixtureId)) {
        throw new TournamentTeamMatchBackfillError(`Fixture ${fixture.id} has an advancement target outside the bounded scope.`);
      }
    }
  }
}

function assertDetailsCompatible(existing: ExistingDetails, fixture: FixtureRow): void {
  const expected = {
    teamMatchId: fixture.id,
    tournamentId: fixture.tournamentId,
    groupId: fixture.groupId,
    round: fixture.round,
    fixtureNumber: fixture.fixtureNumber,
    legNumber: fixture.legNumber,
    parentTeamMatchId: fixture.parentFixtureId,
    homeRegistrationId: fixture.homeRegistrationId,
    awayRegistrationId: fixture.awayRegistrationId,
  };
  for (const key of Object.keys(expected) as Array<keyof typeof expected>) {
    if (existing[key] !== expected[key]) throw new TournamentTeamMatchBackfillError(`Existing tournament match details differ for fixture ${fixture.id} at ${key}.`);
  }
}

export async function migrateTournamentFixtureVideosInTransaction(
  tx: Prisma.TransactionClient,
  fixtureIds: readonly string[],
): Promise<{ videosCreated: number; videosAlreadyPresent: number }> {
  const ids = unique(fixtureIds);
  if (ids.length === 0) return { videosCreated: 0, videosAlreadyPresent: 0 };
  const legacyVideoUrls = await tx.v1TournamentFixtureVideo.findMany({ where: { fixtureId: { in: ids } }, select: { url: true } });
  for (const url of [...new Set(legacyVideoUrls.map((video) => video.url))].sort()) await lockVideoUrl(tx, url);
  const legacyVideos = await tx.v1TournamentFixtureVideo.findMany({
    where: { fixtureId: { in: ids } },
    select: { id: true, fixtureId: true, title: true, url: true, sortOrder: true, createdAt: true },
    orderBy: [{ fixtureId: 'asc' }, { sortOrder: 'asc' }, { createdAt: 'asc' }, { id: 'asc' }],
  });
  const canonicalVideos = await tx.v1TeamMatchVideo.findMany({ where: { teamMatchId: { in: ids } }, select: { id: true, teamMatchId: true, url: true } });
  const videoIdByMatchUrl = new Map<string, string>();
  for (const video of canonicalVideos) {
    const key = `${video.teamMatchId}:${video.url}`;
    const knownId = videoIdByMatchUrl.get(key);
    if (knownId !== undefined && knownId !== video.id) throw new TournamentTeamMatchBackfillError(`Canonical video URL ${video.url} for fixture ${video.teamMatchId} has conflicting IDs (${knownId}, ${video.id}).`);
    videoIdByMatchUrl.set(key, video.id);
  }
  for (const video of legacyVideos) {
    const key = `${video.fixtureId}:${video.url}`;
    const knownId = videoIdByMatchUrl.get(key);
    if (knownId !== undefined && knownId !== video.id) throw new TournamentTeamMatchBackfillError(`Video URL ${video.url} for fixture ${video.fixtureId} has conflicting IDs (${knownId}, ${video.id}).`);
    videoIdByMatchUrl.set(key, video.id);
  }
  let videosCreated = 0;
  let videosAlreadyPresent = 0;
  for (const video of legacyVideos) {
    const existing = await tx.v1TeamMatchVideo.findUnique({ where: { id: video.id }, select: { id: true, teamMatchId: true, title: true, url: true, sortOrder: true, createdAt: true } });
    if (existing !== null) {
      if (existing.teamMatchId !== video.fixtureId || existing.title !== video.title || existing.url !== video.url || existing.sortOrder !== video.sortOrder || existing.createdAt.getTime() !== video.createdAt.getTime()) throw new TournamentTeamMatchBackfillError(`Existing TeamMatch video ${video.id} is incompatible with legacy fixture video ${video.id}.`);
      videosAlreadyPresent += 1;
      continue;
    }
    await tx.v1TeamMatchVideo.create({ data: { id: video.id, teamMatchId: video.fixtureId, title: video.title, url: video.url, sortOrder: video.sortOrder, createdAt: video.createdAt } });
    videosCreated += 1;
  }
  if (legacyVideos.length > 0) await tx.v1TournamentFixtureVideo.deleteMany({ where: { id: { in: legacyVideos.map((video) => video.id) } } });
  return { videosCreated, videosAlreadyPresent };
}

async function applyBackfill(tx: Prisma.TransactionClient, fixtures: FixtureRow[], report: TournamentTeamMatchPreflightReport, before: TournamentTeamMatchBackfillSnapshot, topologyFixtureIds?: readonly string[]): Promise<TournamentTeamMatchBackfillResult> {
  assertPreflightReady(report);
  assertClosedTopology(fixtures, topologyFixtureIds);
  const existingDetails = await tx.v1TournamentMatchDetails.findMany({ where: { teamMatchId: { in: fixtures.map((fixture) => fixture.id) } } });
  const detailsById = new Map(existingDetails.map((detail) => [detail.teamMatchId, detail as ExistingDetails]));
  const existingEdges = await tx.v1TournamentMatchAdvancementEdge.findMany({ where: { tournamentId: { in: unique(fixtures.map((fixture) => fixture.tournamentId)) } } });
  const edgeByKey = new Map(existingEdges.map((edge) => [`${edge.sourceTeamMatchId}:${edge.sourceOutcome}`, edge as ExistingEdge]));
  let teamMatchesCreated = 0;
  let teamMatchesAlreadyPresent = 0;
  let detailsCreated = 0;
  let detailsAlreadyPresent = 0;
  let gamesLinked = 0;
  let advancementEdgesCreated = 0;
  let advancementEdgesAlreadyPresent = 0;
  let videosCreated = 0;
  let videosAlreadyPresent = 0;

  // Phase 1: create all canonical matches and bracket detail rows. Parent links
  // remain null until every target details row exists.
  for (const fixture of fixtures) {
    const teams = resolvedTeamIds(fixture);
    const existingMatch = await tx.v1TeamMatch.findUnique({ where: { id: fixture.id }, select: { id: true, tournamentId: true, sportId: true, competitionConfigVersionId: true } });
    if (existingMatch === null) {
      await tx.v1TeamMatch.create({
        data: {
          id: fixture.id,
          tournamentId: fixture.tournamentId,
          fieldId: fixture.fieldId,
          hostTeamId: teams.homeTeamId,
          createdByUserId: null,
          sportId: fixture.tournament.sportId,
          regionId: null,
          title: derivedTitle(fixture),
          placeName: fixture.venue,
          startAt: fixture.scheduledAt,
          status: fixtureStatusToTeamMatchStatus(fixture.status),
          approvedApplicantTeamId: teams.awayTeamId,
          competitionConfigVersionId: fixture.competitionConfigVersionId ?? fixture.game?.competitionConfigVersionId ?? undefined,
          createdAt: fixture.createdAt,
          updatedAt: fixture.updatedAt,
        },
      });
      teamMatchesCreated += 1;
    } else {
      const existingOperational = await tx.v1TeamMatch.findUnique({ where: { id: fixture.id }, select: { hostTeamId: true, approvedApplicantTeamId: true, fieldId: true, startAt: true, placeName: true, status: true } });
      if (existingOperational === null || existingMatch.tournamentId !== fixture.tournamentId || existingMatch.sportId !== fixture.tournament.sportId || existingMatch.competitionConfigVersionId !== (fixture.competitionConfigVersionId ?? fixture.game?.competitionConfigVersionId ?? null)
        || existingOperational.hostTeamId !== teams.homeTeamId || existingOperational.approvedApplicantTeamId !== teams.awayTeamId
        || existingOperational.fieldId !== fixture.fieldId || existingOperational.startAt?.getTime() !== fixture.scheduledAt?.getTime()
        || existingOperational.placeName !== fixture.venue || existingOperational.status !== fixtureStatusToTeamMatchStatus(fixture.status)) {
        throw new TournamentTeamMatchBackfillError(`Existing TeamMatch ${fixture.id} is incompatible with fixture ${fixture.id}.`);
      }
      teamMatchesAlreadyPresent += 1;
    }
    const existingDetail = detailsById.get(fixture.id);
    if (existingDetail) {
      assertDetailsCompatible(existingDetail, fixture);
      detailsAlreadyPresent += 1;
    } else {
      await tx.v1TournamentMatchDetails.create({
        data: {
          teamMatchId: fixture.id,
          tournamentId: fixture.tournamentId,
          groupId: fixture.groupId,
          round: fixture.round,
          fixtureNumber: fixture.fixtureNumber,
          legNumber: fixture.legNumber,
          parentTeamMatchId: null,
          homeRegistrationId: fixture.homeRegistrationId,
          awayRegistrationId: fixture.awayRegistrationId,
          createdAt: fixture.createdAt,
          updatedAt: fixture.updatedAt,
        },
      });
      detailsCreated += 1;
    }
  }

  // Phase 2: migrate videos without rerunning any canonical match/detail/game work.
  const videoMigration = await migrateTournamentFixtureVideosInTransaction(tx, fixtures.map((fixture) => fixture.id));
  videosCreated += videoMigration.videosCreated;
  videosAlreadyPresent += videoMigration.videosAlreadyPresent;

  // Phase 3: restore parent links now that all details rows exist.
  for (const fixture of fixtures) {
    if (fixture.parentFixtureId === null) continue;
    const current = detailsById.get(fixture.id);
    if (current?.parentTeamMatchId === fixture.parentFixtureId) continue;
    await tx.v1TournamentMatchDetails.update({ where: { teamMatchId: fixture.id }, data: { parentTeamMatchId: fixture.parentFixtureId } });
  }

  // Phase 4: preserve the old source link while adding the canonical TeamMatch link.
  for (const fixture of fixtures) {
    if (fixture.game === null || fixture.game.teamMatchId === fixture.id) continue;
    if (fixture.game.teamMatchId !== null) throw new TournamentTeamMatchBackfillError(`Game ${fixture.game.id} is linked to another TeamMatch.`);
    await tx.v1Game.update({ where: { id: fixture.game.id }, data: { teamMatchId: fixture.id } });
    gamesLinked += 1;
  }

  // Phase 5: copy advancement topology with the preserved fixture IDs (same IDs).
  for (const fixture of fixtures) {
    for (const edge of fixture.advancementSources) {
      const key = `${fixture.id}:${edge.sourceOutcome}`;
      const existing = edgeByKey.get(key);
      if (existing) {
        if (existing.id !== edge.id || existing.tournamentId !== fixture.tournamentId || existing.sourceTeamMatchId !== fixture.id || existing.sourceOutcome !== edge.sourceOutcome || existing.targetTeamMatchId !== edge.targetFixtureId || existing.targetSide !== edge.targetSide || existing.createdAt.getTime() !== edge.createdAt.getTime()) {
          throw new TournamentTeamMatchBackfillError(`Existing advancement edge ${existing.id} differs for fixture ${fixture.id}.`);
        }
        advancementEdgesAlreadyPresent += 1;
        continue;
      }
      await tx.v1TournamentMatchAdvancementEdge.create({
        data: {
          id: edge.id,
          tournamentId: fixture.tournamentId,
          sourceTeamMatchId: fixture.id,
          sourceOutcome: edge.sourceOutcome,
          targetTeamMatchId: edge.targetFixtureId,
          targetSide: edge.targetSide,
          createdAt: edge.createdAt,
        },
      });
      advancementEdgesCreated += 1;
    }
  }

  const expectedEdges: TournamentAdvancementPreservationRow[] = fixtures.flatMap((fixture) => fixture.advancementSources.map((edge) => ({
    id: edge.id,
    tournamentId: fixture.tournamentId,
    sourceTeamMatchId: fixture.id,
    sourceOutcome: edge.sourceOutcome,
    targetTeamMatchId: edge.targetFixtureId,
    targetSide: edge.targetSide,
    createdAt: edge.createdAt,
  })));
  const canonicalEdges = await tx.v1TournamentMatchAdvancementEdge.findMany({
    where: { sourceTeamMatchId: { in: fixtures.map((fixture) => fixture.id) } },
    select: { id: true, tournamentId: true, sourceTeamMatchId: true, sourceOutcome: true, targetTeamMatchId: true, targetSide: true, createdAt: true },
  });
  try {
    assertTournamentAdvancementPreserved(expectedEdges, canonicalEdges);
  } catch (error) {
    if (error instanceof Error) throw new TournamentTeamMatchBackfillError(error.message);
    throw error;
  }

  const after = await snapshot(tx, fixtures.map((fixture) => fixture.id));
  if (JSON.stringify(before.legacyFingerprints) !== JSON.stringify(after.legacyFingerprints)) {
    throw new TournamentTeamMatchBackfillError('Legacy fixture/game IDs or hashes changed during TeamMatch backfill.');
  }
  return {
    preflight: report,
    counts: { fixturesConsidered: fixtures.length, teamMatchesCreated, teamMatchesAlreadyPresent, detailsCreated, detailsAlreadyPresent, gamesLinked, advancementEdgesCreated, advancementEdgesAlreadyPresent, videosCreated, videosAlreadyPresent },
    before,
    after,
  };
}

export async function runTournamentTeamMatchBackfillInTransaction(
  tx: Prisma.TransactionClient,
  options: TournamentTeamMatchBackfillOptions,
): Promise<TournamentTeamMatchBackfillResult> {
  const fixtureIds = await selectFixtureIds(tx, options);
  await lockRows(tx, fixtureIds);
  const report = await preflightTournamentFixtureMigration(asPreflightClient(tx), { fixtureIds });
  assertPreflightReady(report);
  const fixtures = await loadFixtures(tx, fixtureIds);
  const before = await snapshot(tx, fixtureIds);
  return applyBackfill(tx, fixtures, report, before, options.topologyFixtureIds);
}

export async function runTournamentTeamMatchBackfill(prisma: PrismaClient, options: TournamentTeamMatchBackfillOptions): Promise<TournamentTeamMatchBackfillResult> {
  boundedBackfillScope(options);
  return prisma.$transaction(
    (tx) => runTournamentTeamMatchBackfillInTransaction(tx, options),
    { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
  );
}
