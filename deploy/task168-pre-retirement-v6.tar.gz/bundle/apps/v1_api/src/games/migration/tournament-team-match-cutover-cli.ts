import { open, type FileHandle } from 'node:fs/promises';
import { isAbsolute } from 'node:path';
import { PrismaService } from '../../prisma/prisma.service';
import {
  runGuardedTournamentTeamMatchCutover,
  TournamentCutoverGateError,
  TournamentCutoverCommittedGateError,
} from './tournament-team-match-guarded-cutover';
import { TournamentTeamMatchFullCutoverError } from './tournament-team-match-full-cutover';
import type { TournamentTeamMatchPreflightReport } from './tournament-team-match-preflight';

type CutoverReport =
  | { timestamp: string; status: 'RUNNING' }
  | { timestamp: string; status: 'COMPLETED'; result: unknown }
  | {
      timestamp: string;
      status: 'COMPLETED_WITH_GATE_RELEASE_ERROR';
      result: unknown;
      error: { name: string; code?: string };
    }
  | {
      timestamp: string;
      status: 'FAILED';
      error: { name: string; code?: string };
      gateReport?: { status: string; count: number }[];
      preflightReport?: TournamentTeamMatchPreflightReport;
    };

function parseReportPath(argv: readonly string[]): string {
  if (argv.length === 2 && argv[0] === '--report' && isAbsolute(argv[1])) {
    return argv[1];
  }
  if (argv.length === 1 && argv[0].startsWith('--report=')) {
    const reportPath = argv[0].slice('--report='.length);
    if (isAbsolute(reportPath)) return reportPath;
  }
  throw new Error('Usage: --report /absolute/path/to/report.json');
}

function sanitizeError(error: unknown): { name: string; code?: string } {
  if (error instanceof Error) {
    const code = 'code' in error && typeof error.code === 'string' ? error.code : undefined;
    return code === undefined ? { name: error.name } : { name: error.name, code };
  }
  if (typeof error === 'object' && error !== null) {
    const candidate = error as { name?: unknown; code?: unknown };
    const name = typeof candidate.name === 'string' ? candidate.name : 'UnknownError';
    const code = typeof candidate.code === 'string' ? candidate.code : undefined;
    return code === undefined ? { name } : { name, code };
  }
  return { name: 'UnknownError' };
}

async function writeReport(handle: FileHandle, report: CutoverReport): Promise<void> {
  await handle.truncate(0);
  await handle.write(`${JSON.stringify(report)}\n`, 0, 'utf8');
  await handle.datasync();
}

export async function main(argv: readonly string[] = process.argv.slice(2)): Promise<number> {
  let reportPath: string;
  try {
    reportPath = parseReportPath(argv);
  } catch (error) {
    process.stderr.write(`${sanitizeError(error).name}\n`);
    return 1;
  }

  let reportHandle: FileHandle;
  try {
    // Reserve the evidence destination before constructing or mutating Prisma state.
    reportHandle = await open(reportPath, 'wx', 0o600);
  } catch (error) {
    process.stderr.write(`${sanitizeError(error).name}\n`);
    return 1;
  }

  let prisma: PrismaService | undefined;
  let maintenance: PrismaService | undefined;
  let dbCommitted = false;
  try {
    await writeReport(reportHandle, {
      timestamp: new Date().toISOString(),
      status: 'RUNNING',
    });
    prisma = new PrismaService();
    maintenance = new PrismaService();
    const result = await runGuardedTournamentTeamMatchCutover(prisma, maintenance);
    dbCommitted = true;
    try {
      await writeReport(reportHandle, {
        timestamp: new Date().toISOString(),
        status: 'COMPLETED',
        result,
      });
      return 0;
    } catch (reportError) {
      process.stderr.write(`DB_COMMITTED_REPORT_WRITE_FAILED:${sanitizeError(reportError).name}\n`);
      return 2;
    }
  } catch (error) {
    const sanitized = sanitizeError(error);
    if (error instanceof TournamentCutoverCommittedGateError) {
      try {
        await writeReport(reportHandle, {
          timestamp: new Date().toISOString(),
          status: 'COMPLETED_WITH_GATE_RELEASE_ERROR',
          result: error.result,
          error: sanitized,
        });
      } catch (reportError) {
        process.stderr.write(`DB_COMMITTED_REPORT_WRITE_FAILED:${sanitizeError(reportError).name}\n`);
      }
      process.stderr.write(`DB_COMMITTED_GATE_RELEASE_FAILED:${sanitized.code ?? sanitized.name}\n`);
      return 2;
    }
    const gateReport = error instanceof TournamentCutoverGateError ? error.report : undefined;
    const preflightReport = error instanceof TournamentTeamMatchFullCutoverError ? error.report : undefined;
    try {
      await writeReport(reportHandle, {
        timestamp: new Date().toISOString(),
        status: 'FAILED',
        error: sanitized,
        ...(gateReport === undefined ? {} : { gateReport }),
        ...(preflightReport === undefined ? {} : { preflightReport }),
      });
    } catch (reportError) {
      // Preserve both sanitized failure names without exposing database details.
      process.stderr.write(`${sanitized.name}:REPORT_WRITE_FAILED:${sanitizeError(reportError).name}\n`);
    }
    if (dbCommitted) {
      process.stderr.write(`DB_COMMITTED_REPORT_WRITE_FAILED:${sanitized.name}\n`);
      return 2;
    }
    process.stderr.write(`${sanitized.name}${sanitized.code ? `:${sanitized.code}` : ''}\n`);
    return 1;
  } finally {
    try {
      await reportHandle.close();
    } catch (error) {
      process.stderr.write(`REPORT_CLOSE_FAILED:${sanitizeError(error).name}\n`);
    } finally {
      if (prisma !== undefined) {
        try {
          await prisma.$disconnect();
        } catch (error) {
          process.stderr.write(`PRISMA_DISCONNECT_FAILED:${sanitizeError(error).name}\n`);
        }
      }
      if (maintenance !== undefined) {
        try {
          await maintenance.$disconnect();
        } catch (error) {
          process.stderr.write(`MAINTENANCE_DISCONNECT_FAILED:${sanitizeError(error).name}\n`);
        }
      }
    }
  }
}

if (require.main === module) {
  void main().then((exitCode) => {
    process.exitCode = exitCode;
  });
}
