import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { runTournamentTeamMatchFullCutover } from './tournament-team-match-full-cutover';
import { TOURNAMENT_CUTOVER_EXCLUSIVE_LOCK } from '../../common/tournament-cutover-lock';

export class TournamentCutoverGateError extends Error {
  constructor(
    readonly code: 'CUTOVER_ALREADY_RUNNING' | 'CUTOVER_OUTBOX_NOT_DRAINED' | 'CUTOVER_CLAIM_GATE_MISSING',
    readonly report?: { status: string; count: number }[],
  ) {
    super(code);
    this.name = 'TournamentCutoverGateError';
  }
}

export class TournamentCutoverCommittedGateError extends Error {
  readonly code = 'CUTOVER_COMMITTED_GATE_RELEASE_FAILED';
  constructor(readonly result: Awaited<ReturnType<typeof runTournamentTeamMatchFullCutover>>) {
    super('Data cutover committed, but maintenance transaction did not finish cleanly.');
    this.name = 'TournamentCutoverCommittedGateError';
  }
}

/** The maintenance client must have its own pool, even when connection_limit=1. */
export async function runGuardedTournamentTeamMatchCutover(
  prisma: PrismaService,
  maintenance: PrismaService,
) {
  if (prisma === maintenance) throw new Error('Cutover requires a separate maintenance Prisma client.');
  let committedResult: Awaited<ReturnType<typeof runTournamentTeamMatchFullCutover>> | undefined;
  try {
    return await maintenance.$transaction(async (gate) => {
      await gate.$executeRaw`SET LOCAL statement_timeout = '5s'`;
      // claimOne holds the shared counterpart until its claim transaction commits.
      const [lock] = await gate.$queryRaw<{ acquired: boolean }[]>(TOURNAMENT_CUTOVER_EXCLUSIVE_LOCK);
      if (!lock?.acquired) throw new TournamentCutoverGateError('CUTOVER_ALREADY_RUNNING');
      const [trigger] = await gate.$queryRaw<{ installed: boolean }[]>`
        SELECT EXISTS (
          SELECT 1 FROM pg_trigger
          WHERE tgrelid = 'v1_outbox_events'::regclass
            AND tgname = 'v1_guard_outbox_cutover_claim'
            AND tgenabled = 'O'
            AND tgfoid = to_regprocedure('v1_guard_outbox_cutover_claim()')
        ) AS installed
      `;
      if (!trigger?.installed) throw new TournamentCutoverGateError('CUTOVER_CLAIM_GATE_MISSING');
      // READ COMMITTED makes this snapshot newer than the lock acquisition. The
      // Serializable data transaction starts only after all previous claims commit.
      const counts = await gate.v1OutboxEvent.groupBy({ by: ['status'], _count: { _all: true } });
      const queue = counts.map((row) => ({ status: row.status, count: row._count._all }))
        .sort((a, b) => a.status.localeCompare(b.status));
      if (queue.some((row) => row.status === 'PROCESSING' && row.count > 0)) {
        throw new TournamentCutoverGateError('CUTOVER_OUTBOX_NOT_DRAINED', queue);
      }
      const result = await runTournamentTeamMatchFullCutover(prisma, { sealOperationAudits: true });
      committedResult = result;
      return { queueBefore: queue, ...result };
    }, {
      isolationLevel: Prisma.TransactionIsolationLevel.ReadCommitted,
      maxWait: 5_000,
      // Three data attempts are bounded to (5s pool + 30s transaction) each.
      // Gate queries each have a 5s statement bound; leave additional teardown margin.
      timeout: 180_000,
    });
  } catch (error) {
    if (committedResult !== undefined) throw new TournamentCutoverCommittedGateError(committedResult);
    throw error;
  }
}
