import { Prisma, V1GameState } from '@prisma/client';
import { selectHistoricalResultRevision, HistoricalResultRevisionMatchError } from './historical-result-revision-matcher';
import { loadHistoricalResultRevisionMatchInput, HistoricalResultRevisionSourceError } from './historical-result-revision-source';

export type TournamentTeamMatchPreflightClient = Pick<
  Prisma.TransactionClient,
  'v1TournamentFixture' | 'v1TeamMatch' | 'v1GameResultDecision' | 'v1Game' | 'v1TournamentResultLineage'
>;

export type MigrationFindingSeverity = 'BLOCKER' | 'UNRESOLVED' | 'INFO';
export type MigrationPreflightStatus = 'READY' | 'BLOCKED' | 'UNRESOLVED';

export interface MigrationFinding {
  code:
    | 'TEAM_MATCH_ID_COLLISION'
    | 'MISSING_GAME_LINK'
    | 'INCONSISTENT_GAME_LINK'
    | 'REGISTRATION_TOURNAMENT_MISMATCH'
    | 'CONFIGURATION_MISMATCH'
    | 'CONFIGURATION_UNRESOLVED'
    | 'LIVE_GAME'
    | 'IN_PROGRESS_GAME_HISTORY_UNRECOVERABLE'
    | 'RESULT_COMPARISON_UNRESOLVED'
    | 'TOURNAMENT_CONFIGURATION_DRIFT'
    | 'REGISTRATION_LINK_MISSING'
    | 'REGISTRATION_TEAM_MISSING'
    | 'RESULT_POINTER_NOT_OFFICIAL';
  severity: MigrationFindingSeverity;
  message: string;
  details?: Record<string, unknown>;
}

export interface FixtureDependencyCounts {
  fixtureResults: number;
  fixtureGoals: number;
  videos: number;
  advancementSources: number;
  advancementTargets: number;
  staffScopes: number;
  operationAudits: number;
  gamePeriods: number;
  gameEvents: number;
  gameParticipants: number;
  gameLineups: number;
  gameResultRevisions: number;
  gameSides: number;
  visibilityPolicies: number;
  officialCaches: number;
  officialFacts: number;
  teamRecordFacts: number;
  resultParticipants: number;
  resultDecisions: number;
}

export interface FixtureDependencyIds {
  fixtureResults: string[];
  fixtureGoals: string[];
  videos: string[];
  advancementSources: string[];
  advancementTargets: string[];
  staffScopes: string[];
  operationAudits: string[];
  gamePeriods: string[];
  gameEvents: string[];
  gameParticipants: string[];
  gameLineups: string[];
  gameResultRevisions: string[];
  gameSides: string[];
  visibilityPolicies: string[];
  officialCaches: string[];
  officialFacts: string[];
  teamRecordFacts: string[];
  resultParticipants: string[];
  resultDecisions: string[];
}

export interface FixtureMigrationPreflight {
  fixtureId: string;
  tournamentId: string;
  fixtureStatus: import('@prisma/client').V1TournamentFixtureStatus;
  intendedTeamMatchId: string;
  status: MigrationPreflightStatus;
  findings: MigrationFinding[];
  dependencyCounts: FixtureDependencyCounts;
  dependencyIds: FixtureDependencyIds;
  source: {
    historicalRevisionId?: string | null;
    fixtureConfigVersionId: string | null;
    tournamentConfigVersionId: string | null;
    gameId: string | null;
    gameState: V1GameState | null;
    homeRegistrationId: string | null;
    awayRegistrationId: string | null;
    currentOfficialRevisionId: string | null;
    currentOfficialRevisionEventsHash: string | null;
    officialCacheHashes: { id: string; sourceHash: string; payloadHash: string }[];
    officialFactHashes: { id: string; eventsHash: string }[];
    teamRecordFactHashes: { id: string; sourceHash: string }[];
  };
}

export interface TournamentTeamMatchPreflightReport {
  status: MigrationPreflightStatus;
  totals: {
    fixtures: number;
    ready: number;
    blocked: number;
    unresolved: number;
    findings: number;
  };
  fixtures: FixtureMigrationPreflight[];
}

export interface TournamentTeamMatchPreflightOptions {
  tournamentIds?: readonly string[];
  fixtureIds?: readonly string[];
}

export interface PreflightRegistration {
  id: string;
  tournamentId: string;
  teamId: string | null;
}

export interface PreflightGame {
  id: string;
  sourceType: string;
  tournamentFixtureId: string | null;
  teamMatchId: string | null;
  state: V1GameState;
  competitionConfigVersionId: string;
  currentOfficialRevisionId: string | null;
  currentOfficialRevision: { id: string; state: string; score: Prisma.JsonValue; eventsHash: string } | null;
  sides: { id: string }[];
  periods: { id: string }[];
  events: { id: string }[];
  participants: { id: string }[];
  lineups: { id: string }[];
  resultRevisions: { id: string }[];
  visibilityPolicy: { id: string } | null;
  officialResultCaches: { id: string; sourceHash: string; payloadHash: string }[];
  officialFacts: { id: string; eventsHash: string }[];
  teamRecordFacts: { id: string; sourceHash: string }[];
  resultParticipants: { id: string }[];
  resultDecisions: { id: string }[];
}

export interface PreflightTeamMatch {
  id: string;
  tournamentId: string | null;
  sportId: string;
  competitionConfigVersionId: string | null;
  game: PreflightGame | null;
}

export interface PreflightFixtureRow {
  id: string;
  historicalRevision?: { revisionId: string } | { errorCode: string; message: string };
  status: import('@prisma/client').V1TournamentFixtureStatus;
  tournamentId: string;
  competitionConfigVersionId: string | null;
  homeRegistrationId: string | null;
  awayRegistrationId: string | null;
  homeRegistration: PreflightRegistration | null;
  awayRegistration: PreflightRegistration | null;
  tournament: { sportId: string; competitionConfigVersionId: string | null };
  game: PreflightGame | null;
  existingTeamMatch: PreflightTeamMatch | null;
  result: { id: string; homeScore: number; awayScore: number; hasPenalty: boolean; homePenaltyScore: number | null; awayPenaltyScore: number | null; goals: { id: string }[] } | null;
  videos: { id: string }[];
  advancementSources: { id: string }[];
  advancementTargets: { id: string }[];
  staffScopes: { id: string }[];
  operationAudits: { id: string }[];
}

function compareLegacyAndCurrent(row: PreflightFixtureRow, findings: MigrationFinding[]) {
  const game = row.game ?? row.existingTeamMatch?.game;
  if (!game) return;
  if (row.result) {
    if (row.historicalRevision && 'revisionId' in row.historicalRevision) return;
    findings.push({
      code: 'RESULT_COMPARISON_UNRESOLVED', severity: 'UNRESOLVED',
      message: '과거 결과와 득점 기록이 일치하는 원본 리비전을 확정할 수 없어요.',
      details: row.historicalRevision ?? { errorCode: 'HISTORICAL_REVISION_NOT_VERIFIED' },
    });
    return;
  }
  if (game.currentOfficialRevisionId !== null && !game.currentOfficialRevision) {
    findings.push({ code: 'RESULT_POINTER_NOT_OFFICIAL', severity: 'UNRESOLVED', message: '게임의 현재 공식 결과 포인터가 가리키는 리비전을 찾을 수 없어요.', details: { revisionId: game.currentOfficialRevisionId } });
  } else if (game.currentOfficialRevision && game.currentOfficialRevision.state !== 'OFFICIAL') {
    findings.push({ code: 'RESULT_POINTER_NOT_OFFICIAL', severity: 'INFO', message: '현재 결과 포인터가 공식 결과를 가리키지 않아요.', details: { revisionId: game.currentOfficialRevision.id, state: game.currentOfficialRevision.state } });
  }
}
export function assessTournamentFixtureMigrationRow(row: PreflightFixtureRow): FixtureMigrationPreflight {
  const findings: MigrationFinding[] = [];
  const expectedConfig = row.tournament.competitionConfigVersionId;
  const game = row.game ?? row.existingTeamMatch?.game ?? null;
  const fixtureConfig = row.competitionConfigVersionId;
  const teamMatchConfig = row.existingTeamMatch?.competitionConfigVersionId ?? null;
  const authoritativeConfig = fixtureConfig ?? teamMatchConfig ?? game?.competitionConfigVersionId ?? null;

  if (row.existingTeamMatch) {
    const existingConfigCompatible = fixtureConfig !== null
      ? row.existingTeamMatch.competitionConfigVersionId === fixtureConfig
      : row.existingTeamMatch.competitionConfigVersionId === null || row.existingTeamMatch.competitionConfigVersionId === authoritativeConfig;
    const compatible = row.existingTeamMatch.tournamentId === row.tournamentId
      && row.existingTeamMatch.sportId === row.tournament.sportId
      && existingConfigCompatible
      && (row.existingTeamMatch.game === null || row.existingTeamMatch.game.id === game?.id);
    if (!compatible) {
      findings.push({ code: 'TEAM_MATCH_ID_COLLISION', severity: 'BLOCKER', message: '같은 ID의 팀 매치가 다른 경기 문맥을 가리켜 이관할 수 없어요.', details: { existingTournamentId: row.existingTeamMatch.tournamentId, existingGameId: row.existingTeamMatch.game?.id ?? null } });
    }
  }

  if (!game) {
    // A completed fixture with a pinned fixture config and a legacy result is
    // the explicit historical-import path. The backfill creates only the
    // TeamMatch/Details anchors; the result importer creates the canonical Game.
    // Unknown/no-result rows remain blocked because there is no source of truth
    // for a canonical game.
    const historicalImportEligible = fixtureConfig !== null && ((row.result !== null && row.status === 'completed') || (row.result === null && (row.status === 'scheduled' || row.status === 'cancelled')));
    findings.push({ code: 'MISSING_GAME_LINK', severity: historicalImportEligible ? 'INFO' : 'BLOCKER', message: historicalImportEligible
      ? '게임은 없지만 고정 설정이 있어 TeamMatch/Details 선행 이관 후 상태별 canonical Game 생성 경로를 수행해요.'
      : '대진에 연결된 게임이 없어 이관할 수 없어요.' });
  } else {
    const legalLinks = game.sourceType === 'TOURNAMENT_FIXTURE'
      ? game.tournamentFixtureId === row.id && (game.teamMatchId === null || game.teamMatchId === row.id)
      : (game.sourceType === 'TEAM_MATCH' || game.sourceType === 'COMPETITION_FIXTURE')
        ? game.teamMatchId === row.id && (game.tournamentFixtureId === null || game.tournamentFixtureId === row.id)
        : false;
    if (!legalLinks) {
      findings.push({ code: 'INCONSISTENT_GAME_LINK', severity: 'BLOCKER', message: '게임의 대진 출처 링크가 일관되지 않아요.', details: { sourceType: game.sourceType, tournamentFixtureId: game.tournamentFixtureId, teamMatchId: game.teamMatchId } });
    }
    if (game.state === 'LIVE' || game.state === 'PAUSED') {
      findings.push({ code: 'LIVE_GAME', severity: 'BLOCKER', message: '진행 중인 게임은 이관할 수 없어요.', details: { state: game.state } });
    }
    if (row.status === 'in_progress' && game.state === 'SCHEDULED') {
      findings.push({ code: 'IN_PROGRESS_GAME_HISTORY_UNRECOVERABLE', severity: 'BLOCKER', message: '진행 중 대진에 연결된 예정 게임은 과거 기록을 안전하게 판정할 수 없어요.', details: { state: game.state } });
    }
  }

  const registrationPairs = [
    { id: row.homeRegistrationId, registration: row.homeRegistration },
    { id: row.awayRegistrationId, registration: row.awayRegistration },
  ];
  for (const { id, registration } of registrationPairs) {
    if (!registration) {
      if (id !== null) findings.push({ code: 'REGISTRATION_LINK_MISSING', severity: 'BLOCKER', message: '대진이 가리키는 등록 행을 찾을 수 없어요.', details: { registrationId: id } });
      continue;
    }
    if (registration.tournamentId !== row.tournamentId) {
      findings.push({ code: 'REGISTRATION_TOURNAMENT_MISMATCH', severity: 'BLOCKER', message: '대진 등록 팀이 다른 대회에 속해 있어요.', details: { registrationId: registration.id, registrationTournamentId: registration.tournamentId } });
    }
    if (registration.teamId === null && id !== null) {
      findings.push({ code: 'REGISTRATION_TEAM_MISSING', severity: 'BLOCKER', message: '확정된 대진 등록 행에 팀이 없어요.', details: { registrationId: registration.id } });
    }
  }

  if (!authoritativeConfig || (!game?.competitionConfigVersionId && fixtureConfig === null)) {
    findings.push({ code: 'CONFIGURATION_UNRESOLVED', severity: 'UNRESOLVED', message: '기존 대진 또는 게임에 고정된 설정 버전이 없어 이관 기준을 확정할 수 없어요.' });
  } else if (game && ((fixtureConfig !== null && game.competitionConfigVersionId !== fixtureConfig) || (fixtureConfig === null && teamMatchConfig !== null && game.competitionConfigVersionId !== teamMatchConfig))) {
    findings.push({ code: 'CONFIGURATION_MISMATCH', severity: 'BLOCKER', message: '기존 대진과 게임의 설정 버전이 일치하지 않아요.', details: { fixtureConfigVersionId: row.competitionConfigVersionId, gameConfigVersionId: game.competitionConfigVersionId } });
  }
  if (authoritativeConfig !== expectedConfig) {
    findings.push({ code: 'TOURNAMENT_CONFIGURATION_DRIFT', severity: 'INFO', message: '현재 대회 설정이 기존 대진 설정과 달라요. 이는 Task165의 이후 생성 경기 전용 변경으로 보존돼요.', details: { fixtureConfigVersionId: row.competitionConfigVersionId, tournamentConfigVersionId: expectedConfig } });
  }

  compareLegacyAndCurrent(row, findings);
  const dependencyIds: FixtureDependencyIds = {
    fixtureResults: row.result ? [row.result.id] : [],
    fixtureGoals: row.result?.goals.map((goal) => goal.id).sort() ?? [],
    videos: row.videos.map((item) => item.id).sort(),
    advancementSources: row.advancementSources.map((item) => item.id).sort(),
    advancementTargets: row.advancementTargets.map((item) => item.id).sort(),
    staffScopes: row.staffScopes.map((item) => item.id).sort(),
    operationAudits: row.operationAudits.map((item) => item.id).sort(),
    gamePeriods: game?.periods.map((item) => item.id).sort() ?? [],
    gameEvents: game?.events.map((item) => item.id).sort() ?? [],
    gameParticipants: game?.participants.map((item) => item.id).sort() ?? [],
    gameLineups: game?.lineups.map((item) => item.id).sort() ?? [],
    gameResultRevisions: game?.resultRevisions.map((item) => item.id).sort() ?? [],
    gameSides: game?.sides.map((item) => item.id).sort() ?? [],
    visibilityPolicies: game?.visibilityPolicy ? [game.visibilityPolicy.id] : [],
    officialCaches: game?.officialResultCaches.map((item) => item.id).sort() ?? [],
    officialFacts: game?.officialFacts.map((item) => item.id).sort() ?? [],
    teamRecordFacts: game?.teamRecordFacts.map((item) => item.id).sort() ?? [],
    resultParticipants: game?.resultParticipants.map((item) => item.id).sort() ?? [],
    resultDecisions: game?.resultDecisions.map((item) => item.id).sort() ?? [],
  };
  const dependencyCounts = Object.fromEntries(Object.entries(dependencyIds).map(([key, ids]) => [key, ids.length])) as FixtureDependencyCounts;
  const status: MigrationPreflightStatus = findings.some((finding) => finding.severity === 'BLOCKER')
    ? 'BLOCKED'
    : findings.some((finding) => finding.severity === 'UNRESOLVED') ? 'UNRESOLVED' : 'READY';
  return {
    fixtureId: row.id,
    tournamentId: row.tournamentId,
    fixtureStatus: row.status,
    intendedTeamMatchId: row.id,
    status,
    findings,
    dependencyCounts,
    dependencyIds,
    source: {
      historicalRevisionId: row.historicalRevision && 'revisionId' in row.historicalRevision ? row.historicalRevision.revisionId : null,
      fixtureConfigVersionId: row.competitionConfigVersionId,
      tournamentConfigVersionId: expectedConfig,
      gameId: game?.id ?? null,
      gameState: game?.state ?? null,
      homeRegistrationId: row.homeRegistrationId,
      awayRegistrationId: row.awayRegistrationId,
      currentOfficialRevisionId: game?.currentOfficialRevisionId ?? null,
      currentOfficialRevisionEventsHash: game?.currentOfficialRevision?.eventsHash ?? null,
      officialCacheHashes: game?.officialResultCaches ?? [],
      officialFactHashes: game?.officialFacts ?? [],
      teamRecordFactHashes: game?.teamRecordFacts ?? [],
    },
  };
}

const gameSelect = {
  id: true,
  sourceType: true,
  tournamentFixtureId: true,
  teamMatchId: true,
  state: true,
  competitionConfigVersionId: true,
  currentOfficialRevisionId: true,
  currentOfficialRevision: { select: { id: true, state: true, score: true, eventsHash: true } },
  sides: { select: { id: true } },
  periods: { select: { id: true } },
  events: { select: { id: true } },
  participants: { select: { id: true } },
  lineups: { select: { id: true } },
  resultRevisions: {
    select: {
      id: true,
      resultParticipants: { select: { id: true } },
      officialFact: { select: { id: true, eventsHash: true } },
      teamRecordFacts: { select: { id: true, sourceHash: true } },
    },
  },
  visibilityPolicy: { select: { gameId: true } },
  officialResultCaches: { select: { id: true, sourceHash: true, payloadHash: true } },
} satisfies Prisma.V1GameSelect;

const fixtureSelect = {
  id: true,
  tournamentId: true,
  competitionConfigVersionId: true,
  status: true,
  homeRegistrationId: true,
  awayRegistrationId: true,
  tournament: { select: { sportId: true, competitionConfigVersionId: true } },
  homeRegistration: { select: { id: true, tournamentId: true, teamId: true } },
  awayRegistration: { select: { id: true, tournamentId: true, teamId: true } },
  game: { select: gameSelect },
  result: { select: { id: true, homeScore: true, awayScore: true, hasPenalty: true, homePenaltyScore: true, awayPenaltyScore: true, goals: { select: { id: true } } } },
  videos: { select: { id: true } },
  advancementSources: { select: { id: true } },
  advancementTargets: { select: { id: true } },
  staffScopes: { select: { id: true } },
  operationAudits: { select: { id: true } },
} satisfies Prisma.V1TournamentFixtureSelect;

type RawPreflightGame = Prisma.V1GameGetPayload<{ select: typeof gameSelect }>;

function normalizeGame(raw: RawPreflightGame, decisionIdsByRevision: ReadonlyMap<string, string[]>): PreflightGame {
  return {
    id: raw.id,
    sourceType: raw.sourceType,
    tournamentFixtureId: raw.tournamentFixtureId,
    teamMatchId: raw.teamMatchId,
    state: raw.state,
    competitionConfigVersionId: raw.competitionConfigVersionId,
    currentOfficialRevisionId: raw.currentOfficialRevisionId,
    currentOfficialRevision: raw.currentOfficialRevision,
    sides: raw.sides,
    periods: raw.periods,
    events: raw.events,
    participants: raw.participants,
    lineups: raw.lineups,
    resultRevisions: raw.resultRevisions.map(({ id }) => ({ id })),
    visibilityPolicy: raw.visibilityPolicy ? { id: raw.visibilityPolicy.gameId } : null,
    officialResultCaches: raw.officialResultCaches,
    officialFacts: raw.resultRevisions.flatMap((revision) => revision.officialFact ? [revision.officialFact] : []),
    teamRecordFacts: raw.resultRevisions.flatMap((revision) => revision.teamRecordFacts),
    resultParticipants: raw.resultRevisions.flatMap((revision) => revision.resultParticipants),
    resultDecisions: raw.resultRevisions.flatMap((revision) => decisionIdsByRevision.get(revision.id)?.map((id) => ({ id })) ?? []),
  };
}

export async function preflightTournamentFixtureMigration(
  prisma: TournamentTeamMatchPreflightClient,
  options: TournamentTeamMatchPreflightOptions,
): Promise<TournamentTeamMatchPreflightReport> {
  const tournamentIds = options.tournamentIds?.filter(Boolean) ?? [];
  const fixtureIds = options.fixtureIds?.filter(Boolean) ?? [];
  if (tournamentIds.length === 0 && fixtureIds.length === 0) throw new Error('Provide tournamentIds or fixtureIds; an unbounded migration preflight is not allowed.');
  const rows = await prisma.v1TournamentFixture.findMany({
    where: tournamentIds.length > 0 ? { tournamentId: { in: tournamentIds } } : { id: { in: fixtureIds } },
    select: fixtureSelect,
    orderBy: [{ tournamentId: 'asc' }, { id: 'asc' }],
  });
  const existing = await prisma.v1TeamMatch.findMany({ where: { id: { in: rows.map((row) => row.id) } }, select: { id: true, tournamentId: true, sportId: true, competitionConfigVersionId: true, game: { select: gameSelect } } });
  const existingById = new Map(existing.map((teamMatch) => [teamMatch.id, teamMatch]));
  const rawGames = [...rows.map((row) => row.game), ...existing.map((teamMatch) => teamMatch.game)].filter((game): game is RawPreflightGame => game !== null);
  const revisionIds = [...new Set(rawGames.flatMap((game) => game.resultRevisions.map((revision) => revision.id)))];
  const decisions = revisionIds.length === 0
    ? []
    : await prisma.v1GameResultDecision.findMany({ where: { revisionId: { in: revisionIds } }, select: { id: true, revisionId: true }, orderBy: { id: 'asc' } });
  const decisionIdsByRevision = new Map<string, string[]>();
  for (const decision of decisions) decisionIdsByRevision.set(decision.revisionId, [...(decisionIdsByRevision.get(decision.revisionId) ?? []), decision.id]);
  const fixtures: FixtureMigrationPreflight[] = [];
  for (const row of rows) {
    const rawExistingTeamMatch = existingById.get(row.id) ?? null;
    const existingTeamMatch = rawExistingTeamMatch ? { ...rawExistingTeamMatch, game: rawExistingTeamMatch.game ? normalizeGame(rawExistingTeamMatch.game, decisionIdsByRevision) : null } : null;
    const game = row.game ? normalizeGame(row.game, decisionIdsByRevision) : existingTeamMatch?.game ?? null;
    let historicalRevision: PreflightFixtureRow['historicalRevision'];
    if (row.result && game) {
      const stored = await prisma.v1TournamentResultLineage.findUnique({ where: { originalResultId: row.result.id }, select: { gameId: true, officialRevisionId: true } });
      try {
        if (stored && stored.gameId !== game.id) throw new HistoricalResultRevisionSourceError('GAME_OWNERSHIP_MISMATCH', `Stored lineage refers to another Game for ${row.id}.`);
        const match = selectHistoricalResultRevision(await loadHistoricalResultRevisionMatchInput(prisma, row.id, game.id, stored?.officialRevisionId));
        historicalRevision = { revisionId: match.revision.id };
      } catch (error) {
        if (!(error instanceof HistoricalResultRevisionMatchError) && !(error instanceof HistoricalResultRevisionSourceError)) throw error;
        historicalRevision = { errorCode: error.code, message: error.message };
      }
    }
    fixtures.push(assessTournamentFixtureMigrationRow({ ...row, game, existingTeamMatch, historicalRevision }));
  }
  const totals = { fixtures: fixtures.length, ready: fixtures.filter((fixture) => fixture.status === 'READY').length, blocked: fixtures.filter((fixture) => fixture.status === 'BLOCKED').length, unresolved: fixtures.filter((fixture) => fixture.status === 'UNRESOLVED').length, findings: fixtures.reduce((count, fixture) => count + fixture.findings.length, 0) };
  return { status: totals.blocked > 0 ? 'BLOCKED' : totals.unresolved > 0 ? 'UNRESOLVED' : 'READY', totals, fixtures };
}
