-- Read-only preflight for task168-seed-cutover-fullrun.ts. Run before the guarded CLI.
-- Replace only the four UUID literals if the seed namespace is changed.
DO $$
DECLARE
  v_tournament_id text := '68168000-0000-4000-8000-000000000702';
  completed_fixture_id text := '68168000-0000-4000-8000-000000000713';
  target_fixture_id text := '68168000-0000-4000-8000-000000000714';
  scheduled_fixture_id text := '68168000-0000-4000-8000-000000000715';
  cancelled_fixture_id text := '68168000-0000-4000-8000-000000000716';
  fixture_count bigint;
  result_count bigint;
  goal_count bigint;
  video_count bigint;
  advancement_count bigint;
  staff_scope_count bigint;
  audit_scope_count bigint;
  legacy_game_count bigint;
BEGIN
  SELECT count(*) INTO fixture_count FROM v1_tournament_fixtures AS f WHERE f.tournament_id = v_tournament_id;
  SELECT count(*) INTO result_count FROM v1_tournament_fixture_results WHERE fixture_id = completed_fixture_id;
  SELECT count(*) INTO goal_count FROM v1_tournament_fixture_goals WHERE fixture_result_id IN (SELECT id FROM v1_tournament_fixture_results WHERE fixture_id = completed_fixture_id);
  SELECT count(*) INTO video_count FROM v1_tournament_fixture_videos WHERE fixture_id = completed_fixture_id;
  SELECT count(*) INTO advancement_count FROM v1_tournament_fixture_advancement_edges AS e WHERE e.tournament_id = v_tournament_id;
  SELECT count(*) INTO staff_scope_count FROM v1_tournament_staff_fixture_scopes WHERE fixture_id = completed_fixture_id;
  SELECT count(*) INTO audit_scope_count FROM v1_operation_audits WHERE fixture_id = completed_fixture_id;
  SELECT count(*) INTO legacy_game_count FROM v1_games WHERE tournament_fixture_id = completed_fixture_id AND source_type::text = 'TOURNAMENT_FIXTURE';
  IF fixture_count <> 4 OR result_count <> 1 OR goal_count <> 1 OR video_count <> 1 OR advancement_count <> 1 OR staff_scope_count <> 1 OR audit_scope_count <> 1 OR legacy_game_count <> 1 THEN
    RAISE EXCEPTION 'TASK168_FULLRUN_PREFLIGHT_FAILED fixtures=% results=% goals=% videos=% advancement=% staff_scopes=% audits=%', fixture_count, result_count, goal_count, video_count, advancement_count, staff_scope_count, audit_scope_count;
  END IF;
  IF EXISTS (SELECT 1 FROM v1_games WHERE team_match_id IN (target_fixture_id, scheduled_fixture_id, cancelled_fixture_id) OR tournament_fixture_id IN (target_fixture_id, scheduled_fixture_id, cancelled_fixture_id)) THEN
    RAISE EXCEPTION 'TASK168_FULLRUN_PREFLIGHT_FAILED no-result fixtures already have Games';
  END IF;
  RAISE NOTICE 'TASK168_FULLRUN_PREFLIGHT_OK fixtures=4 result=1 goal=1 video=1 advancement=1 staff_scope=1 audit=1 legacy_games=1 no_result_games=0';
END $$;
