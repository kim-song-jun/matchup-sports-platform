import { PrismaService } from '../../apps/v1_api/src/prisma/prisma.service';
import { FOOTBALL_V1_CONFIG } from '../../apps/v1_api/src/tournaments/competition-config/competition-config';

/**
 * Standalone pre-cutover fixture for the immutable Task 168 release artifact.
 * Run only against a disposable pre-seal clone; this file intentionally has no
 * cleanup or reset path so the cutover report can be compared afterward.
 */
const id = (suffix: string) => `68168000-0000-4000-8000-${suffix.padStart(12, '0')}`;
const ids = {
  sport: id('700'), config: id('701'), tournament: id('702'), owner: id('703'), homeUser: id('704'), awayUser: id('705'),
  region: id('706'), homeTeam: id('707'), awayTeam: id('708'), homeRegistration: id('709'), awayRegistration: id('710'),
  homePlayer: id('711'), awayPlayer: id('712'), completedFixture: id('713'), targetFixture: id('714'), scheduledFixture: id('715'),
  cancelledFixture: id('716'), completedGame: id('717'), completedRevision: id('718'), completedResult: id('719'), completedGoal: id('720'),
  completedHomeSide: id('721'), completedAwaySide: id('722'), legacyVideo: id('723'), advancement: id('724'),
  staffAssignment: id('725'), staffScope: id('726'), audit: id('727'),
} as const;

async function main() {
  const databaseUrl = new URL(process.env.DATABASE_URL ?? '');
  const databaseName = databaseUrl.pathname.replace(/^\//, '');
  if (databaseUrl.hostname !== '127.0.0.1' || databaseUrl.port !== '55435' || !/^teameet_task168_fullrun(?:_|$)/.test(databaseName)) {
    throw new Error('Task168 full-run seed requires a teameet_task168_fullrun* clone on 127.0.0.1:55435');
  }
  const prisma = new PrismaService();
  try {
    const result = await prisma.$transaction(async (tx) => {
      await tx.v1Sport.create({ data: { id: ids.sport, code: `task168-full-${ids.sport.slice(-6)}`, name: 'Task 168 full-run sport', sortOrder: 1 } });
      await tx.v1CompetitionConfigVersion.create({
        data: {
          id: ids.config, sportCode: 'football', name: 'Task 168 full-run config', version: 1,
          periods: FOOTBALL_V1_CONFIG.periods, events: FOOTBALL_V1_CONFIG.events, lineup: FOOTBALL_V1_CONFIG.lineup,
          result: FOOTBALL_V1_CONFIG.result, tieBreak: FOOTBALL_V1_CONFIG.tieBreak, visibility: FOOTBALL_V1_CONFIG.visibility,
          contentHash: `task168-full-${ids.config}`,
        },
      });
      await tx.v1Tournament.create({ data: { id: ids.tournament, sportId: ids.sport, title: 'Task 168 full-run source', status: 'in_progress', kind: 'regular_tournament', competitionConfigVersionId: ids.config } });
      await tx.v1User.createMany({ data: [
        { id: ids.owner, email: `${ids.owner}@task168-full.example.test`, accountStatus: 'active', onboardingStatus: 'completed' },
        { id: ids.homeUser, email: `${ids.homeUser}@task168-full.example.test`, accountStatus: 'active', onboardingStatus: 'completed' },
        { id: ids.awayUser, email: `${ids.awayUser}@task168-full.example.test`, accountStatus: 'active', onboardingStatus: 'completed' },
      ] });
      await tx.v1Region.create({ data: { id: ids.region, code: `task168-full-${ids.region.slice(-6)}`, name: 'Task 168 full-run region', level: 1 } });
      await tx.v1Team.createMany({ data: [
        { id: ids.homeTeam, ownerUserId: ids.owner, sportId: ids.sport, regionId: ids.region, name: 'Task 168 Home' },
        { id: ids.awayTeam, ownerUserId: ids.owner, sportId: ids.sport, regionId: ids.region, name: 'Task 168 Away' },
      ] });
      await tx.v1TournamentRegistration.createMany({ data: [
        { id: ids.homeRegistration, tournamentId: ids.tournament, teamId: ids.homeTeam, appliedByUserId: ids.owner, status: 'confirmed', confirmedAt: new Date('2026-08-01T00:00:00.000Z') },
        { id: ids.awayRegistration, tournamentId: ids.tournament, teamId: ids.awayTeam, appliedByUserId: ids.owner, status: 'confirmed', confirmedAt: new Date('2026-08-01T00:00:00.000Z') },
      ] });
      await tx.v1TournamentPlayer.createMany({ data: [
        { id: ids.homePlayer, registrationId: ids.homeRegistration, userId: ids.homeUser, realName: 'Task 168 Home Player', addedAt: new Date('2026-08-01T00:00:00.000Z') },
        { id: ids.awayPlayer, registrationId: ids.awayRegistration, userId: ids.awayUser, realName: 'Task 168 Away Player', addedAt: new Date('2026-08-01T00:00:00.000Z') },
      ] });
      await tx.v1TournamentFixture.createMany({ data: [
        { id: ids.completedFixture, tournamentId: ids.tournament, round: 'group', fixtureNumber: 1, status: 'completed', competitionConfigVersionId: ids.config, homeRegistrationId: ids.homeRegistration, awayRegistrationId: ids.awayRegistration, scheduledAt: new Date('2026-08-02T09:00:00.000Z') },
        { id: ids.targetFixture, tournamentId: ids.tournament, round: 'final', fixtureNumber: 2, status: 'scheduled', competitionConfigVersionId: ids.config },
        { id: ids.scheduledFixture, tournamentId: ids.tournament, round: 'group', fixtureNumber: 3, status: 'scheduled', competitionConfigVersionId: ids.config },
        { id: ids.cancelledFixture, tournamentId: ids.tournament, round: 'group', fixtureNumber: 4, status: 'cancelled', competitionConfigVersionId: ids.config },
      ] });
      await tx.v1Game.create({ data: { id: ids.completedGame, sourceType: 'TOURNAMENT_FIXTURE', tournamentFixtureId: ids.completedFixture, competitionConfigVersionId: ids.config, state: 'ENDED' } });
      await tx.v1GameSide.createMany({ data: [
        { id: ids.completedHomeSide, gameId: ids.completedGame, sideKey: 'HOME', teamId: ids.homeTeam, displayNameSnapshot: 'Task 168 Home' },
        { id: ids.completedAwaySide, gameId: ids.completedGame, sideKey: 'AWAY', teamId: ids.awayTeam, displayNameSnapshot: 'Task 168 Away' },
      ] });
      const officialRevision = await tx.v1GameResultRevision.create({ data: {
        id: ids.completedRevision, gameId: ids.completedGame, revision: 1, state: 'OFFICIAL', officialAt: new Date('2026-08-02T11:00:00.000Z'),
        score: { regulation: { home: 1, away: 0 }, penalty: null, provenance: 'TOURNAMENT_FIXTURE_RESULT', goals: [{ team: 'home', playerId: ids.homePlayer, playerName: 'Task 168 Home Player', minute: 17 }] },
        goalEvents: null, eventsHash: 'task168-fullrun-official', createdByActorType: 'SYSTEM', createdBySystemActor: 'GAME_BACKFILL',
      } });
      await tx.v1Game.update({ where: { id: ids.completedGame }, data: { currentOfficialRevisionId: officialRevision.id } });
      await tx.v1TournamentFixtureResult.create({ data: { id: ids.completedResult, fixtureId: ids.completedFixture, homeScore: 1, awayScore: 0, hasPenalty: false, recordedAt: new Date('2026-08-02T11:00:00.000Z') } });
      await tx.v1TournamentFixtureGoal.create({ data: { id: ids.completedGoal, fixtureResultId: ids.completedResult, team: 'home', playerId: ids.homePlayer, playerName: 'Task 168 Home Player', minute: 17 } });
      await tx.v1TournamentFixtureVideo.create({ data: { id: ids.legacyVideo, fixtureId: ids.completedFixture, title: 'Task 168 legacy video', url: 'https://example.test/task168-video', sortOrder: 1 } });
      await tx.v1TournamentFixtureAdvancementEdge.create({ data: { id: ids.advancement, tournamentId: ids.tournament, sourceFixtureId: ids.completedFixture, sourceOutcome: 'WINNER', targetFixtureId: ids.targetFixture, targetSide: 'HOME' } });
      await tx.v1TeamMatch.create({ data: { id: ids.completedFixture, tournamentId: ids.tournament, sportId: ids.sport, title: 'Task 168 mixed canonical match', competitionConfigVersionId: ids.config, status: 'completed', hostTeamId: ids.homeTeam, approvedApplicantTeamId: ids.awayTeam, startAt: new Date('2026-08-02T09:00:00.000Z') } });
      await tx.v1TournamentMatchDetails.create({ data: { teamMatchId: ids.completedFixture, tournamentId: ids.tournament, round: 'group', fixtureNumber: 1, homeRegistrationId: ids.homeRegistration, awayRegistrationId: ids.awayRegistration } });
      await tx.v1TournamentStaffAssignment.create({ data: { id: ids.staffAssignment, tournamentId: ids.tournament, userId: ids.owner, role: 'FIELD_OPERATOR', grantedByUserId: ids.owner } });
      await tx.v1TournamentStaffFixtureScope.create({ data: { id: ids.staffScope, assignmentId: ids.staffAssignment, fixtureId: ids.completedFixture, tournamentId: ids.tournament } });
      await tx.v1OperationAudit.create({ data: { id: ids.audit, actorType: 'USER', actorUserId: ids.owner, action: 'SOURCE_CUTOVER_FIXTURE_EDIT', resourceType: 'TOURNAMENT_FIXTURE', resourceId: ids.completedFixture, requestId: id('728'), before: { status: 'scheduled' }, after: { status: 'completed' }, reason: 'Task 168 full-run seed', tournamentId: ids.tournament, fixtureId: ids.completedFixture } });
      return { tournamentId: ids.tournament, completedFixtureId: ids.completedFixture, targetFixtureId: ids.targetFixture, scheduledFixtureId: ids.scheduledFixture, cancelledFixtureId: ids.cancelledFixture, completedGameId: ids.completedGame };
    });
    process.stdout.write(`${JSON.stringify(result)}\n`);
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((error) => {
  const code = typeof error === 'object' && error !== null && 'code' in error ? String(error.code) : undefined;
  const name = error instanceof Error ? error.name : 'UnknownError';
  const message = error instanceof Error ? error.message.split(/\r?\n/).filter(Boolean).at(-1) ?? name : 'UnknownError';
  process.stderr.write(`${JSON.stringify({ name, ...(code ? { code } : {}), message: message.slice(0, 240) })}\n`);
  process.exitCode = 1;
});
