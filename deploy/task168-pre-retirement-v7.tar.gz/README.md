# Task 168 pre-retirement cutover release v7

This directory is an immutable, pre-schema-retirement release artifact. It contains the cutover runner and its recursively resolved local TypeScript dependencies, the pinned workspace lockfile, Prisma schema, the three retirement migrations, and the disposable full-run seed/preflight assets.

## Isolated execution

This artifact is a cutover bundle, not a complete Prisma migration history. It cannot initialize a blank database. A nonempty database without a Prisma migration baseline may reject `prisma migrate deploy` with P3005. Apply the bundled SQL files explicitly in the order below against an already prepared pre-retirement database clone.

1. Use Node >=22 and pnpm@9.15.4.
2. Verify `MANIFEST.json` and `SHA256SUMS`, then enter the bundled workspace: `cd bundle`.
3. Run `pnpm --filter v1_api... install --offline --frozen-lockfile --ignore-scripts`.
4. Run `pnpm --filter v1_api exec prisma generate --schema prisma/schema.prisma`. This creates the pinned @prisma/client runtime from the bundled schema; no generated client is read from the source working tree.
5. Set DATABASE_URL in the process environment without writing it to this artifact. Only for a synthetic QA rehearsal, the optional seed accepts a disposable database named `teameet_task168_fullrun*` on 127.0.0.1:55435. From bundle/apps/v1_api run `pnpm exec ts-node --project tsconfig.json ../../scripts/qa/task168-seed-cutover-fullrun.ts` once, then from bundle verify with `psql -v ON_ERROR_STOP=1 "$DATABASE_URL" --file scripts/qa/task168-preflight-cutover-fullrun.sql`. Never seed an operational database or a real-data rehearsal clone.
6. Before the data cutover, install the outbox claim gate if it is not already present in the clone: `psql -v ON_ERROR_STOP=1 "$DATABASE_URL" --single-transaction --file apps/v1_api/prisma/migrations/20260910160000_v1_outbox_cutover_claim_gate/migration.sql`. Do not reapply this migration when its trigger already exists; the runner validates the installed claim gate. This prerequisite must be installed before the runner; it protects PROCESSING claims. PENDING, RETRY, and POISONED rows are reported and preserved, and do not need to be zero.
7. Run `pnpm --filter v1_api exec node -r ts-node/register/transpile-only src/games/migration/tournament-team-match-cutover-cli.ts --report /absolute/cutover-report.json`. The report path must be absolute and previously unused.
8. Only after a successful data cutover, apply the remaining bundled SQL in this order: `psql -v ON_ERROR_STOP=1 "$DATABASE_URL" --single-transaction --file apps/v1_api/prisma/migrations/20260910010000_v1_official_fact_source_history/migration.sql`, then `psql -v ON_ERROR_STOP=1 "$DATABASE_URL" --single-transaction --file apps/v1_api/prisma/migrations/20260910020000_v1_canonical_game_db_guards/migration.sql`. The guard migration requires the five legacy write seals and three legacy-link seals installed by the completed cutover when historical legacy rows remain.

## Completion checks

Accept the run only when the report has `status: "COMPLETED"`, a READY preflight, zero remaining legacy Game/staff/audit links, and successful legacy-write/audit sealing. Keep the report and post-migration row hashes as evidence. The runner never prints DATABASE_URL or raw SQL.
