import { Prisma, V1VisibilityMode } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import {
  preflightTournamentFixtureMigration,
  type TournamentTeamMatchPreflightReport,
} from './tournament-team-match-preflight';
import {
  runTournamentTeamMatchBackfillInTransaction,
  migrateTournamentFixtureVideosInTransaction,
  type TournamentTeamMatchBackfillResult,
} from './tournament-team-match-backfill';
import {
  cutoverTournamentFixtureGameSourcesInTransaction,
  type TournamentTeamMatchSourceCutoverResult,
} from './tournament-team-match-source-cutover';
import { importHistoricalFixtureResult } from './historical-fixture-result-import';
import { captureTournamentResultLineage } from './tournament-result-lineage';
import { importHistoricalFixtureWithoutResult } from './historical-fixture-no-result-import';
import { computePeriodCount, jsonObject } from '../games.service';
import { participantDisplayName } from '../../tournaments/participant-display-name';
import { sealTournamentOperationAudits } from './tournament-operation-audit-seal';
import { lockTournamentLegacyWrites, sealTournamentLegacyWrites } from './tournament-legacy-write-seal';
import { assertTournamentAdvancementPreserved } from './tournament-advancement-preservation';
import { GameResultStandingsProjectionService } from '../../game-operations/game-result-standings-projection.service';
import { officialRevisionRowSelect } from '../../game-operations/official-revision-row.query';
import { normalizeOfficialRevisionRow } from '../../game-operations/official-revision-row.normalizer';
import type { OfficialRevisionRowRaw } from '../../game-operations/game-result-official-projection.types';

export interface TournamentTeamMatchFullCutoverResult {
  status: 'COMPLETED' | 'NOOP';
  auditMutationSealed?: true;
  legacyWritesSealed?: true;
  fixtureIds: string[];
  resultLineageDisposition: Array<{
    originalResultId: string;
    originalFixtureId: string;
    teamMatchId: string;
    gameId: string;
    officialRevisionId: string;
    status: 'VERIFIED';
  }>;
  preflight: TournamentTeamMatchPreflightReport;
  backfill: TournamentTeamMatchBackfillResult | null;
  sourceCutover: TournamentTeamMatchSourceCutoverResult | null;
  verification: {
    fixtureCount: number;
    detailsCount: number;
    canonicalGameCount: number;
    remainingLegacyGameLinks: number;
    remainingLegacyStaffScopes: number;
    remainingLegacyAuditScopes: number;
  };
}

export class TournamentTeamMatchFullCutoverError extends Error {
  constructor(
    readonly code: 'PREFLIGHT_BLOCKED' | 'LEGACY_RESULT_LINEAGE_UNVERIFIED' | 'POST_CUTOVER_INCOMPLETE',
    message: string,
    readonly report?: TournamentTeamMatchPreflightReport,
  ) {
    super(message);
    this.name = 'TournamentTeamMatchFullCutoverError';
  }
}

async function projectDeferredHistoricalStandings(
  tx: Prisma.TransactionClient,
  revisionIds: string[],
): Promise<void> {
  const standings = new GameResultStandingsProjectionService();
  for (const revisionId of revisionIds) {
    const rows = await tx.$queryRaw<OfficialRevisionRowRaw[]>`${officialRevisionRowSelect()} WHERE revision.id = ${revisionId}`;
    if (rows.length !== 1) throw new TournamentTeamMatchFullCutoverError('POST_CUTOVER_INCOMPLETE', `Deferred historical revision ${revisionId} could not be resolved through the canonical projection source.`);
    await standings.project(tx, normalizeOfficialRevisionRow(rows[0]));
  }
}

async function runInTransaction(
  tx: Prisma.TransactionClient,
): Promise<TournamentTeamMatchFullCutoverResult> {
  // No SELECT may precede these locks: Serializable would otherwise retain a
  // snapshot which omits rows committed while the maintenance locks were waiting.
  // Drain Game writers first, matching their Game -> fixture lock order.
  // EXCLUSIVE also drains SELECT FOR UPDATE holders (ROW SHARE table lock),
  // which may not have issued their Game UPDATE yet.
  await tx.$executeRaw`LOCK TABLE "v1_games" IN EXCLUSIVE MODE`;
  await tx.$executeRaw`LOCK TABLE "v1_operation_audits" IN SHARE ROW EXCLUSIVE MODE`;
  await tx.$executeRaw`LOCK TABLE "v1_tournament_staff_fixture_scopes" IN SHARE ROW EXCLUSIVE MODE`;
  await lockTournamentLegacyWrites(tx);
  const fixtures = await tx.v1TournamentFixture.findMany({
    select: { id: true },
    orderBy: { id: 'asc' },
  });
  const fixtureIds = fixtures.map((fixture) => fixture.id);
  if (fixtureIds.length === 0) {
    const [remainingLegacyGameLinks, remainingLegacyStaffScopes, remainingLegacyAuditScopes] = await Promise.all([
      tx.v1Game.count({ where: { tournamentFixtureId: { not: null } } }),
      tx.v1TournamentStaffFixtureScope.count({ where: { fixtureId: { not: null } } }),
      tx.v1OperationAudit.count({ where: { fixtureId: { not: null } } }),
    ]);
    if (remainingLegacyGameLinks !== 0 || remainingLegacyStaffScopes !== 0 || remainingLegacyAuditScopes !== 0) {
      throw new TournamentTeamMatchFullCutoverError('POST_CUTOVER_INCOMPLETE', 'Empty fixture dataset still has legacy links or audit scopes.');
    }
    return {
      status: 'NOOP',
      fixtureIds: [],
      resultLineageDisposition: [],
      preflight: { status: 'READY', totals: { fixtures: 0, ready: 0, blocked: 0, unresolved: 0, findings: 0 }, fixtures: [] },
      backfill: null,
      sourceCutover: null,
      verification: { fixtureCount: 0, detailsCount: 0, canonicalGameCount: 0, remainingLegacyGameLinks, remainingLegacyStaffScopes, remainingLegacyAuditScopes },
    };
  }

  const preflight = await preflightTournamentFixtureMigration(tx, { fixtureIds });
  if (preflight.status !== 'READY') {
    throw new TournamentTeamMatchFullCutoverError(
      'PREFLIGHT_BLOCKED',
      `Full TeamMatch cutover preflight is ${preflight.status}; no rows were mutated.`,
      preflight,
    );
  }
  const [canonicalMatches, canonicalDetails, canonicalGames] = await Promise.all([
    tx.v1TeamMatch.findMany({ where: { id: { in: fixtureIds } }, select: { id: true, tournamentId: true } }),
    tx.v1TournamentMatchDetails.findMany({ where: { teamMatchId: { in: fixtureIds } }, select: { teamMatchId: true, tournamentId: true } }),
    tx.v1Game.findMany({ where: { teamMatchId: { in: fixtureIds } }, select: { id: true, teamMatchId: true, sourceType: true, tournamentFixtureId: true } }),
  ]);
  const matchById = new Map(canonicalMatches.map((row) => [row.id, row]));
  const detailsById = new Map(canonicalDetails.map((row) => [row.teamMatchId, row]));
  const gameByTeamMatchId = new Map(canonicalGames.map((row) => [row.teamMatchId, row]));
  const canonicalFixtureIds = fixtureIds.filter((fixtureId) => {
    const expectedTournamentId = preflight.fixtures.find((fixture) => fixture.fixtureId === fixtureId)?.tournamentId;
    const match = matchById.get(fixtureId);
    const details = detailsById.get(fixtureId);
    const game = gameByTeamMatchId.get(fixtureId);
    return match?.tournamentId === expectedTournamentId
      && details?.tournamentId === expectedTournamentId
      && game?.sourceType === 'TEAM_MATCH'
      && game.tournamentFixtureId === null;
  });
  const pendingFixtureIds = fixtureIds.filter((fixtureId) => !canonicalFixtureIds.includes(fixtureId));
  if (pendingFixtureIds.length > 0) {
    const pendingTopology = await tx.v1TournamentFixture.findMany({
      where: { id: { in: pendingFixtureIds } },
      select: {
        id: true,
        parentFixtureId: true,
        advancementSources: { select: { targetFixtureId: true } },
      },
    });
    const pendingSet = new Set(pendingFixtureIds);
    const canonicalSet = new Set(canonicalFixtureIds);
    for (const fixture of pendingTopology) {
      const references = [
        ...(fixture.parentFixtureId === null ? [] : [fixture.parentFixtureId]),
        ...fixture.advancementSources.map((edge) => edge.targetFixtureId),
      ];
      const outsideAnchor = references.find((reference) => !pendingSet.has(reference) && !canonicalSet.has(reference));
      if (outsideAnchor !== undefined) {
        throw new TournamentTeamMatchFullCutoverError(
          'PREFLIGHT_BLOCKED',
          `Pending fixture ${fixture.id} references topology fixture ${outsideAnchor} outside the complete canonical/pending dataset.`,
          preflight,
        );
      }
    }
  }
  const backfill = pendingFixtureIds.length > 0
    ? await runTournamentTeamMatchBackfillInTransaction(tx, { fixtureIds: pendingFixtureIds, topologyFixtureIds: fixtureIds })
    : null;
  // Only game-less historical results need a new Game. Existing histories keep
  // every revision and pointer, and acquire their lineage after source cutover.
  const resultFixtures = preflight.fixtures
    .filter((fixture) => fixture.dependencyIds.fixtureResults.length > 0)
    .sort((a, b) => a.fixtureId.localeCompare(b.fixtureId));
  const deferredHistoricalRevisionIds: string[] = [];
  for (const fixture of resultFixtures) {
    if (fixture.source.gameId === null) {
      const imported = await importHistoricalFixtureResult(tx, fixture.fixtureId, { deferStandings: true });
      deferredHistoricalRevisionIds.push(imported.revisionId);
    }
  }
  const noResultFixtureIds = preflight.fixtures
    .filter((fixture) => fixture.source.gameId === null && fixture.dependencyIds.fixtureResults.length === 0 && (fixture.fixtureStatus === 'scheduled' || fixture.fixtureStatus === 'cancelled'))
    .map((fixture) => fixture.fixtureId)
    .sort();
  if (noResultFixtureIds.length > 0) {
    const noResultRows = await tx.v1TournamentFixture.findMany({
      where: { id: { in: noResultFixtureIds } },
      select: {
        id: true, status: true, competitionConfigVersionId: true, createdAt: true, updatedAt: true,
        homeRegistration: { select: { status: true, team: { select: { id: true, name: true } }, players: { where: { removedAt: null }, select: { userId: true, jerseyNumber: true, user: { select: { profile: { select: { nickname: true, displayName: true } } } } }, orderBy: { id: 'asc' } } } },
        awayRegistration: { select: { status: true, team: { select: { id: true, name: true } }, players: { where: { removedAt: null }, select: { userId: true, jerseyNumber: true, user: { select: { profile: { select: { nickname: true, displayName: true } } } } }, orderBy: { id: 'asc' } } } },
      },
    });
    const configIds = [...new Set(noResultRows.map((row) => row.competitionConfigVersionId).filter((id): id is string => id !== null))];
    const configs = await tx.v1CompetitionConfigVersion.findMany({ where: { id: { in: configIds } }, select: { id: true, periods: true, visibility: true } });
    const configById = new Map(configs.map((config) => [config.id, config]));
    for (const row of noResultRows) {
      if (row.status !== 'scheduled' && row.status !== 'cancelled') throw new TournamentTeamMatchFullCutoverError('PREFLIGHT_BLOCKED', `No-result fixture ${row.id} has unsupported status ${row.status}.`, preflight);
      if (!row.competitionConfigVersionId) throw new TournamentTeamMatchFullCutoverError('PREFLIGHT_BLOCKED', `No-result fixture ${row.id} has no pinned config.`, preflight);
      const config = configById.get(row.competitionConfigVersionId);
      if (!config) throw new TournamentTeamMatchFullCutoverError('PREFLIGHT_BLOCKED', `No-result fixture ${row.id} has an unavailable pinned config.`, preflight);
      const visibility = jsonObject(config.visibility);
      const visibilityMode = visibility.mode === 'status_only'
        ? V1VisibilityMode.STATUS_ONLY
        : visibility.mode === undefined || visibility.mode === 'live'
          ? V1VisibilityMode.LIVE
          : null;
      if (visibilityMode === null) {
        throw new TournamentTeamMatchFullCutoverError('PREFLIGHT_BLOCKED', `No-result fixture ${row.id} has unsupported visibility mode ${String(visibility.mode)}.`, preflight);
      }
      const scheduledRegistrations = [row.homeRegistration, row.awayRegistration];
      if (row.status === 'scheduled' && scheduledRegistrations.some((registration) => registration !== null && registration.status !== 'confirmed')) {
        throw new TournamentTeamMatchFullCutoverError('PREFLIGHT_BLOCKED', `Scheduled fixture ${row.id} requires confirmed registrations when a side is assigned.`, preflight);
      }
      await importHistoricalFixtureWithoutResult(tx, {
        fixtureId: row.id,
        status: row.status as 'scheduled' | 'cancelled',
        competitionConfigVersionId: config.id,
        periodCount: computePeriodCount(config.periods),
        homeTeamId: row.homeRegistration?.team.id ?? null,
        awayTeamId: row.awayRegistration?.team.id ?? null,
        homeTeamName: row.homeRegistration?.team.name ?? '홈 팀 미정',
        awayTeamName: row.awayRegistration?.team.name ?? '어웨이 팀 미정',
        participants: [
          ...(row.homeRegistration?.players ?? []).map((player) => ({ sideKey: 'HOME' as const, userId: player.userId, displayNameSnapshot: participantDisplayName(player), jerseyNumber: player.jerseyNumber ?? undefined })),
          ...(row.awayRegistration?.players ?? []).map((player) => ({ sideKey: 'AWAY' as const, userId: player.userId, displayNameSnapshot: participantDisplayName(player), jerseyNumber: player.jerseyNumber ?? undefined })),
        ],
        visibilityMode,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      });
    }
  }
  // Canonical fixtures can still carry legacy videos even when their TeamMatch,
  // Details, and Game rows already exist. Migrate only this video phase for the
  // full bounded set; never rerun canonical match/detail/game backfill.
  await migrateTournamentFixtureVideosInTransaction(tx, fixtureIds);
  const sourceCutover = await cutoverTournamentFixtureGameSourcesInTransaction(tx, fixtureIds);
  if (!sourceCutover) throw new TournamentTeamMatchFullCutoverError('POST_CUTOVER_INCOMPLETE', 'No source rows were available for cutover.');
  // Verify even fixtures which were already canonical and skipped backfill.
  // A count or source/outcome lookup alone cannot preserve the original edge ID.
  const legacyEdges = await tx.v1TournamentFixtureAdvancementEdge.findMany({
    where: { sourceFixtureId: { in: fixtureIds } },
  });
  const canonicalEdges = await tx.v1TournamentMatchAdvancementEdge.findMany({
    where: { id: { in: legacyEdges.map((edge) => edge.id) } },
  });
  assertTournamentAdvancementPreserved(legacyEdges.map((edge) => ({
    id: edge.id, tournamentId: edge.tournamentId,
    sourceTeamMatchId: edge.sourceFixtureId, sourceOutcome: edge.sourceOutcome,
    targetTeamMatchId: edge.targetFixtureId, targetSide: edge.targetSide,
    createdAt: edge.createdAt,
  })), canonicalEdges);
  for (const fixture of resultFixtures) {
    if (fixture.source.gameId === null) continue;
    if (!fixture.source.historicalRevisionId) throw new TournamentTeamMatchFullCutoverError('LEGACY_RESULT_LINEAGE_UNVERIFIED', `Fixture ${fixture.fixtureId} has no verified historical revision.`, preflight);
    await captureTournamentResultLineage(tx, {
      originalFixtureId: fixture.fixtureId,
      teamMatchId: fixture.fixtureId,
      gameId: fixture.source.gameId,
      officialRevisionId: fixture.source.historicalRevisionId,
    });
  }
  // Every game-less historical import must finish its canonical game/result
  // creation before standings reads the group. Otherwise the first sibling's
  // projection observes an incomplete batch and can raise CANONICAL_MATCH_REQUIRED.
  await projectDeferredHistoricalStandings(tx, deferredHistoricalRevisionIds);

  // Every legacy result in the migration scope must have exactly one immutable
  // lineage row bound back to the same fixture/tournament/TeamMatch/Game. A
  // count-only check can miss an omitted result or a row captured for the wrong
  // fixture, which would make the cutover appear complete while losing history.
  const expectedLineage = resultFixtures.flatMap((fixture) =>
    fixture.dependencyIds.fixtureResults.map((originalResultId) => ({
      originalResultId,
      originalFixtureId: fixture.fixtureId,
      tournamentId: fixture.tournamentId,
    })),
  );
  const lineageRows = await tx.v1TournamentResultLineage.findMany({
    where: {
      OR: [
        { originalResultId: { in: expectedLineage.map((row) => row.originalResultId) } },
        { originalFixtureId: { in: fixtureIds } },
        { teamMatchId: { in: fixtureIds } },
      ],
    },
    select: {
      originalResultId: true,
      originalFixtureId: true,
      originalFixtureTournamentId: true,
      tournamentId: true,
      teamMatchId: true,
      gameId: true,
      officialRevisionId: true,
    },
  });
  const expectedByResultId = new Map(expectedLineage.map((row) => [row.originalResultId, row]));
  const lineageIds = new Set(lineageRows.map((row) => row.originalResultId));
  const missingLineage = expectedLineage.find((row) => !lineageIds.has(row.originalResultId));
  const unexpectedLineage = lineageRows.find((row) => !expectedByResultId.has(row.originalResultId));
  const misboundLineage = lineageRows.find((row) => {
    const expected = expectedByResultId.get(row.originalResultId);
    return expected === undefined
      || row.originalFixtureId !== expected.originalFixtureId
      || row.originalFixtureTournamentId !== expected.tournamentId
      || row.tournamentId !== expected.tournamentId
      || row.teamMatchId !== expected.originalFixtureId;
  });
  const lineageGameIds = [...new Set(lineageRows.map((row) => row.gameId))];
  const lineageGames = lineageGameIds.length === 0
    ? []
    : await tx.v1Game.findMany({
      where: { id: { in: lineageGameIds } },
      select: { id: true, sourceType: true, teamMatchId: true, tournamentFixtureId: true },
    });
  const gameById = new Map(lineageGames.map((game) => [game.id, game]));
  const brokenGameBinding = lineageRows.find((row) => {
    const game = gameById.get(row.gameId);
    return game === undefined
      || game.sourceType !== 'TEAM_MATCH'
      || game.teamMatchId !== row.teamMatchId
      || game.tournamentFixtureId !== null;
  });
  const lineageRevisionIds = [...new Set(lineageRows.map((row) => row.officialRevisionId))];
  const revisionRows = lineageRevisionIds.length === 0
    ? []
    : await tx.v1GameResultRevision.findMany({
      where: { id: { in: lineageRevisionIds } },
      select: { id: true, gameId: true, state: true },
    });
  const revisionById = new Map(revisionRows.map((revision) => [revision.id, revision]));
  const brokenRevisionBinding = lineageRows.find((row) => {
    const revision = revisionById.get(row.officialRevisionId);
    return revision === undefined || revision.gameId !== row.gameId || revision.state !== 'OFFICIAL';
  });
  if (missingLineage || unexpectedLineage || misboundLineage || brokenGameBinding || brokenRevisionBinding || lineageRows.length !== expectedLineage.length) {
    throw new TournamentTeamMatchFullCutoverError(
      'POST_CUTOVER_INCOMPLETE',
      `Legacy result lineage set is not an exact bound set (expected ${expectedLineage.length}, found ${lineageRows.length}; missing=${missingLineage?.originalResultId ?? 'none'}; unexpected=${unexpectedLineage?.originalResultId ?? 'none'}; misbound=${misboundLineage?.originalResultId ?? brokenGameBinding?.originalResultId ?? brokenRevisionBinding?.originalResultId ?? 'none'}).`,
    );
  }

  const [detailsCount, canonicalGameCount, remainingLegacyGameLinks, remainingLegacyStaffScopes, remainingLegacyAuditScopes] = await Promise.all([
    tx.v1TournamentMatchDetails.count({ where: { teamMatchId: { in: fixtureIds } } }),
    tx.v1Game.count({ where: { teamMatchId: { in: fixtureIds }, sourceType: 'TEAM_MATCH', tournamentFixtureId: null } }),
    tx.v1Game.count({ where: { tournamentFixtureId: { not: null } } }),
    tx.v1TournamentStaffFixtureScope.count({ where: { fixtureId: { not: null } } }),
    tx.v1OperationAudit.count({ where: { fixtureId: { not: null } } }),
  ]);
  if (detailsCount !== fixtureIds.length || canonicalGameCount !== fixtureIds.length || remainingLegacyGameLinks !== 0 || remainingLegacyStaffScopes !== 0 || remainingLegacyAuditScopes !== 0) {
    throw new TournamentTeamMatchFullCutoverError('POST_CUTOVER_INCOMPLETE', 'Full TeamMatch cutover left legacy links or missing canonical rows.');
  }

  const lineageByResultId = new Map(lineageRows.map((row) => [row.originalResultId, row]));
  const resultLineageDisposition = expectedLineage
    .slice()
    .sort((a, b) => a.originalResultId.localeCompare(b.originalResultId))
    .map(({ originalResultId }) => {
      const row = lineageByResultId.get(originalResultId);
      if (row === undefined) {
        throw new TournamentTeamMatchFullCutoverError('POST_CUTOVER_INCOMPLETE', `Verified lineage row ${originalResultId} disappeared before reporting.`);
      }
      return {
        originalResultId: row.originalResultId,
        originalFixtureId: row.originalFixtureId,
        teamMatchId: row.teamMatchId,
        gameId: row.gameId,
        officialRevisionId: row.officialRevisionId,
        status: 'VERIFIED' as const,
      };
    });

  return {
    status: 'COMPLETED',
    fixtureIds,
    resultLineageDisposition,
    preflight,
    backfill,
    sourceCutover,
    verification: { fixtureCount: fixtureIds.length, detailsCount, canonicalGameCount, remainingLegacyGameLinks, remainingLegacyStaffScopes, remainingLegacyAuditScopes },
  };
}

export async function runTournamentTeamMatchFullCutover(
  prisma: PrismaService,
  options: { sealOperationAudits?: boolean } = {},
): Promise<TournamentTeamMatchFullCutoverResult> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      return await prisma.$transaction(async (tx) => {
        const result = await runInTransaction(tx);
        if (options.sealOperationAudits) {
          // Canonical game/result writes may queue deferred constraint triggers
          // (notably the current-official-revision pointer). PostgreSQL refuses
          // ALTER TABLE while those events are pending, so flush and validate
          // them at the completed-write boundary before installing retirement
          // triggers. This keeps sealing in the same transaction without
          // disabling constraints or creating a second commit boundary.
          await tx.$executeRaw`SET CONSTRAINTS ALL IMMEDIATE`;
          await sealTournamentOperationAudits(tx);
          await sealTournamentLegacyWrites(tx);
          return { ...result, auditMutationSealed: true as const, legacyWritesSealed: true as const };
        }
        return result;
      }, {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        maxWait: 5_000,
        timeout: 30_000,
      });
    } catch (error) {
      lastError = error;
      const retryable = error instanceof Prisma.PrismaClientKnownRequestError
        ? error.code === 'P2034'
          || (error.code === 'P2010' && (error.meta?.code === '40P01' || error.meta?.code === '40001'))
        : typeof error === 'object' && error !== null && 'code' in error
          && (error.code === '40P01' || error.code === '40001');
      if (!retryable || attempt === 3) throw error;
    }
  }
  throw lastError;
}
