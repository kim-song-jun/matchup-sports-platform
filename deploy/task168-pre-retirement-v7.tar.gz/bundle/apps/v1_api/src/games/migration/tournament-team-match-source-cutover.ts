import { Prisma, V1GameSideKey, V1GameSourceType } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { GameResultPublicCacheService } from '../../game-operations/game-result-public-cache.service';
import { parseOfficialScore } from '../../game-operations/parse-official-score';
import { officialRevisionRowSelect } from '../../game-operations/official-revision-row.query';
import { normalizeOfficialRevisionRow } from '../../game-operations/official-revision-row.normalizer';
import type { OfficialRevisionRowRaw } from '../../game-operations/game-result-official-projection.types';
import { resolveTournamentTeamIds } from './tournament-team-match-backfill';

export class TournamentTeamMatchSourceCutoverError extends Error {
  readonly code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = 'TournamentTeamMatchSourceCutoverError';
    this.code = code;
  }
}

export interface TournamentTeamMatchSourceCutoverResult {
  fixtureIds: string[];
  convertedGameIds: string[];
  alreadyCanonicalGameIds: string[];
  staffScopesConverted: number;
  preserved: {
    gameIds: string[];
    currentOfficialRevisionIds: (string | null)[];
    periodIds: string[];
    eventIds: string[];
    revisionIds: string[];
    officialFactIds: string[];
    officialCacheIds: string[];
    auditIds: string[];
  };
  preservedAfter: TournamentTeamMatchSourceCutoverResult['preserved'];
}

type Tx = Prisma.TransactionClient;

function expectedTeamMatchStatus(status: string): string {
  if (status === 'completed') return 'completed';
  if (status === 'cancelled') return 'cancelled';
  return 'matched';
}

const uniqueSorted = (ids: readonly string[]) => [...new Set(ids.filter((id) => id.trim() !== ''))].sort();

async function lockSourceRows(tx: Tx, fixtureIds: string[]) {
  await tx.$queryRaw(Prisma.sql`
    SELECT id FROM "v1_games"
    WHERE tournament_fixture_id IN (${Prisma.join(fixtureIds)})
       OR team_match_id IN (${Prisma.join(fixtureIds)})
    ORDER BY id
    FOR UPDATE
  `);
  await tx.$queryRaw(Prisma.sql`
    SELECT id FROM "v1_tournament_fixtures"
    WHERE id IN (${Prisma.join(fixtureIds)})
    ORDER BY id
    FOR UPDATE
  `);
  await tx.$queryRaw(Prisma.sql`
    SELECT id FROM "v1_team_matches"
    WHERE id IN (${Prisma.join(fixtureIds)})
    ORDER BY id
    FOR UPDATE
  `);
  await tx.$queryRaw(Prisma.sql`
    SELECT team_match_id FROM "v1_tournament_match_details"
    WHERE team_match_id IN (${Prisma.join(fixtureIds)})
    ORDER BY team_match_id
    FOR UPDATE
  `);
  await tx.$queryRaw(Prisma.sql`
    SELECT id FROM "v1_operation_audits"
    WHERE fixture_id IN (${Prisma.join(fixtureIds)})
       OR team_match_id IN (${Prisma.join(fixtureIds)})
    ORDER BY id
    FOR UPDATE
  `);
}

type OperationAuditSnapshot = {
  actorType: string;
  actorUserId: string | null;
  systemActor: string | null;
  action: string;
  resourceType: string;
  resourceId: string;
  requestId: string;
  maskedSourceIp: string | null;
  before: Prisma.JsonValue | null;
  after: Prisma.JsonValue | null;
  reason: string | null;
  tournamentId: string | null;
  fieldId: string | null;
  createdAt: Date;
};

type OperationAuditRow = OperationAuditSnapshot & {
  id: string;
  fixtureId: string | null;
  teamMatchId: string | null;
};

function auditSnapshot(row: OperationAuditRow): OperationAuditSnapshot {
  return {
    actorType: row.actorType,
    actorUserId: row.actorUserId,
    systemActor: row.systemActor,
    action: row.action,
    resourceType: row.resourceType,
    resourceId: row.resourceId,
    requestId: row.requestId,
    maskedSourceIp: row.maskedSourceIp,
    before: row.before,
    after: row.after,
    reason: row.reason,
    tournamentId: row.tournamentId,
    fieldId: row.fieldId,
    createdAt: row.createdAt,
  };
}

function sameAuditSnapshot(left: OperationAuditSnapshot, right: OperationAuditSnapshot): boolean {
  return JSON.stringify({ ...left, createdAt: left.createdAt.toISOString() })
    === JSON.stringify({ ...right, createdAt: right.createdAt.toISOString() });
}

async function reprojectOfficialCaches(tx: Tx, fixtureIds: string[], ownershipByGame: ReadonlyMap<string, { tournamentId: string; teamMatchId: string }>) {
  const rows = await tx.v1GameOfficialResultCache.findMany({
    where: { gameId: { in: (await tx.v1Game.findMany({ where: { teamMatchId: { in: fixtureIds } }, select: { id: true } })).map((row) => row.id) } },
    select: {
      id: true, gameId: true, revisionId: true, sourceHash: true,
    },
  });
  if (rows.length > 0) {
    await tx.$queryRaw(Prisma.sql`
      SELECT id FROM "v1_game_official_result_cache"
      WHERE id IN (${Prisma.join(rows.map((row) => row.id))})
      ORDER BY id
      FOR UPDATE
    `);
  }
  const cache = new GameResultPublicCacheService();
  // Game is already locked. Taking a revision lock here would invert the
  // official worker's revision -> Game order; official revisions are read-only.
  const revisions = rows.length === 0 ? [] : await tx.$queryRaw<Array<OfficialRevisionRowRaw & { state: string }>>(Prisma.sql`
    ${officialRevisionRowSelect()}
    WHERE revision.id IN (${Prisma.join(rows.map((row) => row.revisionId))})
    ORDER BY revision.id
  `);
  const rawRevisionById = new Map(revisions.map((row) => [row.revisionId, row]));
  const revisionById = new Map(revisions.map((row) => [row.revisionId, normalizeOfficialRevisionRow(row)]));
  for (const row of rows) {
    const revision = revisionById.get(row.revisionId);
    const rawRevision = rawRevisionById.get(row.revisionId);
    if (!revision || !rawRevision || rawRevision.state !== 'OFFICIAL' || revision.sourceType !== V1GameSourceType.TEAM_MATCH || row.sourceHash !== revision.sourceHash) throw new TournamentTeamMatchSourceCutoverError('CACHE_REVISION_MISMATCH', `Official cache ${row.id} does not exactly match its canonical official revision.`);
    const ownership = ownershipByGame.get(row.gameId);
    if (ownership === undefined || revision.teamMatchId !== ownership.teamMatchId || revision.tournamentId !== ownership.tournamentId) throw new TournamentTeamMatchSourceCutoverError('CACHE_GAME_NOT_CUTOVER', `Official cache ${row.id} has no canonical TeamMatch ownership.`);
    const projection = cache.build(revision, parseOfficialScore(revision.score));
    await cache.project(tx, revision, projection);
  }
}

export async function cutoverTournamentFixtureGameSourcesInTransaction(
  tx: Prisma.TransactionClient,
  fixtureIds: readonly string[],
): Promise<TournamentTeamMatchSourceCutoverResult> {
  const ids = uniqueSorted(fixtureIds);
  if (ids.length === 0) throw new TournamentTeamMatchSourceCutoverError('EMPTY_FIXTURE_IDS', 'fixtureIds must contain at least one non-empty ID.');

  await lockSourceRows(tx, ids);
    const fixtures = await tx.v1TournamentFixture.findMany({
      where: { id: { in: ids } },
      orderBy: { id: 'asc' },
      select: {
        id: true,
        tournamentId: true,
        competitionConfigVersionId: true,
        groupId: true,
        round: true,
        fixtureNumber: true,
        legNumber: true,
        parentFixtureId: true,
        scheduledAt: true,
        fieldId: true,
        venue: true,
        status: true,
        homeRegistrationId: true,
        awayRegistrationId: true,
        homeRegistration: { select: { id: true, tournamentId: true, teamId: true } },
        awayRegistration: { select: { id: true, tournamentId: true, teamId: true } },
        game: {
          select: {
            id: true, sourceType: true, tournamentFixtureId: true, teamMatchId: true,
            competitionConfigVersionId: true, currentOfficialRevisionId: true,
            sides: { select: { sideKey: true, teamId: true } },
            periods: { select: { id: true } }, events: { select: { id: true } },
            resultRevisions: {
              select: { id: true, officialFact: { select: { id: true } }, officialResultCache: { select: { id: true } } },
            },
          },
        },
        videos: { select: { id: true } },
        operationAudits: { select: { id: true } },
        tournament: { select: { sportId: true } },
      },
    });
    if (fixtures.length !== ids.length) {
      const found = new Set(fixtures.map((fixture) => fixture.id));
      throw new TournamentTeamMatchSourceCutoverError('FIXTURE_NOT_FOUND', `Missing fixture IDs: ${ids.filter((id) => !found.has(id)).join(', ')}`);
    }

    const matches = await tx.v1TeamMatch.findMany({
      where: { id: { in: ids } },
      select: {
        id: true, tournamentId: true, leagueId: true, sportId: true, competitionConfigVersionId: true,
        hostTeamId: true, approvedApplicantTeamId: true,
        startAt: true, fieldId: true, placeName: true, status: true,
        game: {
          select: {
            id: true, sourceType: true, tournamentFixtureId: true, teamMatchId: true,
            competitionConfigVersionId: true, currentOfficialRevisionId: true,
            sides: { select: { sideKey: true, teamId: true } },
            periods: { select: { id: true } }, events: { select: { id: true } },
            resultRevisions: { select: { id: true, officialFact: { select: { id: true } }, officialResultCache: { select: { id: true } } } },
          },
        },
        tournamentDetails: { select: { teamMatchId: true, tournamentId: true, groupId: true, round: true, fixtureNumber: true, legNumber: true, parentTeamMatchId: true, homeRegistrationId: true, awayRegistrationId: true } },
      },
    });
    const matchById = new Map(matches.map((match) => [match.id, match]));
    const scopes = await tx.v1TournamentStaffFixtureScope.findMany({
      where: { OR: [{ fixtureId: { in: ids } }, { teamMatchId: { in: ids } }] },
      select: { id: true, assignmentId: true, fixtureId: true, teamMatchId: true, tournamentId: true },
      orderBy: { id: 'asc' },
    });
    const audits = await tx.v1OperationAudit.findMany({
      where: { OR: [{ fixtureId: { in: ids } }, { teamMatchId: { in: ids } }] },
      select: {
        id: true, actorType: true, actorUserId: true, systemActor: true, action: true,
        resourceType: true, resourceId: true, requestId: true, maskedSourceIp: true,
        before: true, after: true, reason: true, tournamentId: true, fixtureId: true,
        teamMatchId: true, fieldId: true, createdAt: true,
      },
      orderBy: { id: 'asc' },
    });
    const scopesById = new Map<string, typeof scopes>();
    for (const scope of scopes) scopesById.set(scope.fixtureId ?? scope.teamMatchId ?? '', [...(scopesById.get(scope.fixtureId ?? scope.teamMatchId ?? '') ?? []), scope]);
    const auditBefore = new Map(audits.map((audit) => [audit.id, auditSnapshot(audit)]));

    const convertedGameIds: string[] = [];
    const alreadyCanonicalGameIds: string[] = [];
    const preserved = { gameIds: [], currentOfficialRevisionIds: [], periodIds: [], eventIds: [], revisionIds: [], officialFactIds: [], officialCacheIds: [], auditIds: [] } as TournamentTeamMatchSourceCutoverResult['preserved'];
    let staffScopesConverted = 0;

    for (const fixture of fixtures) {
      const match = matchById.get(fixture.id);
      if (fixture.game && match?.game && fixture.game.id !== match.game.id) throw new TournamentTeamMatchSourceCutoverError('GAME_COLLISION', `Fixture ${fixture.id} and TeamMatch point to different games.`);
      const game = fixture.game ?? match?.game ?? null;
      if (!game) throw new TournamentTeamMatchSourceCutoverError('MISSING_GAME', `Fixture ${fixture.id} has no game.`);
      if (!match || !match.tournamentDetails) throw new TournamentTeamMatchSourceCutoverError('MISSING_CANONICAL_ROWS', `Fixture ${fixture.id} lacks same-ID TeamMatch/Details.`);
      const alreadyCanonical = game.sourceType === V1GameSourceType.TEAM_MATCH && game.teamMatchId === fixture.id && game.tournamentFixtureId === null;
      if (match.tournamentId !== fixture.tournamentId || match.tournamentDetails.tournamentId !== fixture.tournamentId || match.tournamentDetails.teamMatchId !== fixture.id || match.sportId !== fixture.tournament.sportId) throw new TournamentTeamMatchSourceCutoverError('TOURNAMENT_MISMATCH', `Fixture ${fixture.id} canonical tournament ownership differs.`);
      if (match.competitionConfigVersionId === null || game.competitionConfigVersionId !== match.competitionConfigVersionId || (!alreadyCanonical && fixture.competitionConfigVersionId !== null && match.competitionConfigVersionId !== fixture.competitionConfigVersionId)) throw new TournamentTeamMatchSourceCutoverError('CONFIGURATION_MISMATCH', `Fixture ${fixture.id} canonical config differs.`);
      if (!alreadyCanonical && (match.tournamentDetails.homeRegistrationId !== fixture.homeRegistrationId || match.tournamentDetails.awayRegistrationId !== fixture.awayRegistrationId)) throw new TournamentTeamMatchSourceCutoverError('REGISTRATION_MISMATCH', `Fixture ${fixture.id} Details registration ownership differs.`);
      if (!alreadyCanonical) for (const registration of [fixture.homeRegistration, fixture.awayRegistration]) if (registration && registration.tournamentId !== fixture.tournamentId) throw new TournamentTeamMatchSourceCutoverError('REGISTRATION_MISMATCH', `Fixture ${fixture.id} registration belongs to another tournament.`);
      if (!alreadyCanonical) {
        let resolvedTeams: { homeTeamId: string | null; awayTeamId: string | null };
        try {
          resolvedTeams = resolveTournamentTeamIds({
            fixtureId: fixture.id,
            homeFromGame: fixture.game?.sides.find((side) => side.sideKey === V1GameSideKey.HOME)?.teamId ?? null,
            awayFromGame: fixture.game?.sides.find((side) => side.sideKey === V1GameSideKey.AWAY)?.teamId ?? null,
            homeFromRegistration: fixture.homeRegistration?.teamId ?? null,
            awayFromRegistration: fixture.awayRegistration?.teamId ?? null,
          });
        } catch (error) {
          throw new TournamentTeamMatchSourceCutoverError('TEAM_MISMATCH', error instanceof Error ? error.message : `Fixture ${fixture.id} has conflicting team IDs.`);
        }
        if (resolvedTeams.homeTeamId !== match.hostTeamId) throw new TournamentTeamMatchSourceCutoverError('TEAM_MISMATCH', `Fixture ${fixture.id} home team differs.`);
        if (resolvedTeams.awayTeamId !== match.approvedApplicantTeamId) throw new TournamentTeamMatchSourceCutoverError('TEAM_MISMATCH', `Fixture ${fixture.id} away team differs.`);
      }
      if (!alreadyCanonical && (match.startAt?.getTime() !== fixture.scheduledAt?.getTime() || match.fieldId !== fixture.fieldId || match.placeName !== fixture.venue || match.status !== expectedTeamMatchStatus(fixture.status) || match.tournamentDetails.groupId !== fixture.groupId || match.tournamentDetails.round !== fixture.round || match.tournamentDetails.fixtureNumber !== fixture.fixtureNumber || match.tournamentDetails.legNumber !== fixture.legNumber || match.tournamentDetails.parentTeamMatchId !== fixture.parentFixtureId)) throw new TournamentTeamMatchSourceCutoverError('CANONICAL_COORDINATE_MISMATCH', `Fixture ${fixture.id} canonical schedule or bracket coordinates differ.`);
      if (fixture.videos.length > 0) throw new TournamentTeamMatchSourceCutoverError('LEGACY_VIDEOS_REMAIN', `Fixture ${fixture.id} still has legacy videos; run video backfill first.`);
      if (game.sourceType !== V1GameSourceType.TOURNAMENT_FIXTURE && game.sourceType !== V1GameSourceType.TEAM_MATCH) throw new TournamentTeamMatchSourceCutoverError('UNSUPPORTED_SOURCE', `Game ${game.id} has unsupported source ${game.sourceType}.`);
      if (game.sourceType === V1GameSourceType.TOURNAMENT_FIXTURE && (game.tournamentFixtureId !== fixture.id || (game.teamMatchId !== null && game.teamMatchId !== fixture.id))) throw new TournamentTeamMatchSourceCutoverError('SOURCE_LINK_MISMATCH', `Game ${game.id} source links are inconsistent.`);
      if (game.sourceType === V1GameSourceType.TEAM_MATCH && (game.teamMatchId !== fixture.id || (game.tournamentFixtureId !== null && game.tournamentFixtureId !== fixture.id))) throw new TournamentTeamMatchSourceCutoverError('SOURCE_LINK_MISMATCH', `Game ${game.id} canonical links are inconsistent.`);

      const matchingScopes = scopesById.get(fixture.id) ?? [];
      const duplicateCanonical = matchingScopes.filter((scope) => scope.teamMatchId === fixture.id);
      const legacyScopes = matchingScopes.filter((scope) => scope.fixtureId === fixture.id);
      if (legacyScopes.some((legacy) => duplicateCanonical.some((canonical) => canonical.assignmentId === legacy.assignmentId))) throw new TournamentTeamMatchSourceCutoverError('STAFF_SCOPE_COLLISION', `Fixture ${fixture.id} has duplicate legacy/canonical staff scope.`);
      for (const scope of legacyScopes) {
        await tx.v1TournamentStaffFixtureScope.update({ where: { id: scope.id }, data: { fixtureId: null, teamMatchId: fixture.id, tournamentId: fixture.tournamentId } });
        staffScopesConverted += 1;
      }
      const matchingAudits = audits.filter((audit) => audit.fixtureId === fixture.id || audit.teamMatchId === fixture.id);
      for (const audit of matchingAudits) {
        if (audit.tournamentId !== fixture.tournamentId) {
          throw new TournamentTeamMatchSourceCutoverError('AUDIT_SCOPE_CONFLICT', `Operation audit ${audit.id} belongs to another tournament.`);
        }
        if (audit.teamMatchId !== null && audit.teamMatchId !== fixture.id) {
          throw new TournamentTeamMatchSourceCutoverError('AUDIT_SCOPE_CONFLICT', `Operation audit ${audit.id} is bound to another TeamMatch.`);
        }
        if (audit.fixtureId === fixture.id) {
          await tx.v1OperationAudit.update({
            where: { id: audit.id },
            data: { fixtureId: null, teamMatchId: fixture.id },
          });
        }
      }
      preserved.gameIds.push(game.id); preserved.currentOfficialRevisionIds.push(game.currentOfficialRevisionId);
      preserved.periodIds.push(...game.periods.map((row) => row.id)); preserved.eventIds.push(...game.events.map((row) => row.id));
      preserved.revisionIds.push(...game.resultRevisions.map((row) => row.id)); preserved.officialFactIds.push(...game.resultRevisions.flatMap((row) => row.officialFact?.id ?? [])); preserved.officialCacheIds.push(...game.resultRevisions.flatMap((row) => row.officialResultCache?.id ?? []));
      preserved.auditIds.push(...matchingAudits.map((row) => row.id));
      if (alreadyCanonical) alreadyCanonicalGameIds.push(game.id);
      else { await tx.v1Game.update({ where: { id: game.id }, data: { sourceType: V1GameSourceType.TEAM_MATCH, teamMatchId: fixture.id, tournamentFixtureId: null } }); convertedGameIds.push(game.id); }
    }
    const ownershipByGame = new Map<string, { tournamentId: string; teamMatchId: string }>();
    for (const fixture of fixtures) {
      const match = matchById.get(fixture.id);
      const gameId = fixture.game?.id ?? match?.game?.id;
      if (gameId) ownershipByGame.set(gameId, { tournamentId: fixture.tournamentId, teamMatchId: fixture.id });
    }
    await reprojectOfficialCaches(tx, ids, ownershipByGame);
    const afterGames = await tx.v1Game.findMany({
      where: { id: { in: preserved.gameIds } },
      orderBy: { id: 'asc' },
      select: {
        id: true, currentOfficialRevisionId: true,
        periods: { select: { id: true }, orderBy: { id: 'asc' } }, events: { select: { id: true }, orderBy: { id: 'asc' } },
        resultRevisions: { select: { id: true, officialFact: { select: { id: true } }, officialResultCache: { select: { id: true } } }, orderBy: { id: 'asc' } },
      },
    });
    const preservedAfter = {
      gameIds: afterGames.map((row) => row.id),
      currentOfficialRevisionIds: afterGames.map((row) => row.currentOfficialRevisionId),
      periodIds: afterGames.flatMap((row) => row.periods.map((item) => item.id)),
      eventIds: afterGames.flatMap((row) => row.events.map((item) => item.id)),
      revisionIds: afterGames.flatMap((row) => row.resultRevisions.map((item) => item.id)),
      officialFactIds: afterGames.flatMap((row) => row.resultRevisions.flatMap((item) => item.officialFact?.id ?? [])),
      officialCacheIds: afterGames.flatMap((row) => row.resultRevisions.flatMap((item) => item.officialResultCache?.id ?? [])),
      auditIds: [...preserved.auditIds].sort(),
    };
    const auditsAfter = preserved.auditIds.length === 0
      ? []
      : await tx.v1OperationAudit.findMany({
        where: { id: { in: preserved.auditIds } },
        select: {
          id: true, actorType: true, actorUserId: true, systemActor: true, action: true,
          resourceType: true, resourceId: true, requestId: true, maskedSourceIp: true,
          before: true, after: true, reason: true, tournamentId: true, fixtureId: true,
          teamMatchId: true, fieldId: true, createdAt: true,
        },
        orderBy: { id: 'asc' },
      });
    if (auditsAfter.length !== preserved.auditIds.length
      || auditsAfter.some((audit) => audit.fixtureId !== null
        || audit.teamMatchId === null
        || !ids.includes(audit.teamMatchId)
        || !sameAuditSnapshot(auditBefore.get(audit.id)!, auditSnapshot(audit)))) {
      throw new TournamentTeamMatchSourceCutoverError('AUDIT_PRESERVATION_CHECK_FAILED', 'Operation audit identity or immutable fields changed during source cutover.');
    }
    const stable = (values: string[]) => [...values].sort();
    const beforePointers = new Map(preserved.gameIds.map((gameId, index) => [gameId, preserved.currentOfficialRevisionIds[index]]));
    const afterPointers = new Map(preservedAfter.gameIds.map((gameId, index) => [gameId, preservedAfter.currentOfficialRevisionIds[index]]));
    if (JSON.stringify([...beforePointers].sort()) !== JSON.stringify([...afterPointers].sort())
      || JSON.stringify(stable(preservedAfter.periodIds)) !== JSON.stringify(stable(preserved.periodIds))
      || JSON.stringify(stable(preservedAfter.eventIds)) !== JSON.stringify(stable(preserved.eventIds))
      || JSON.stringify(stable(preservedAfter.revisionIds)) !== JSON.stringify(stable(preserved.revisionIds))
      || JSON.stringify(stable(preservedAfter.officialFactIds)) !== JSON.stringify(stable(preserved.officialFactIds))
      || JSON.stringify(stable(preservedAfter.officialCacheIds)) !== JSON.stringify(stable(preserved.officialCacheIds))) {
      throw new TournamentTeamMatchSourceCutoverError('PRESERVATION_CHECK_FAILED', 'Game-owned historical rows changed during source cutover.');
    }
  return { fixtureIds: ids, convertedGameIds, alreadyCanonicalGameIds, staffScopesConverted, preserved, preservedAfter };
}

export async function cutoverTournamentFixtureGameSources(
  prisma: PrismaService,
  fixtureIds: readonly string[],
): Promise<TournamentTeamMatchSourceCutoverResult> {
  return prisma.$transaction(
    (tx) => cutoverTournamentFixtureGameSourcesInTransaction(tx, fixtureIds),
    { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
  );
}
